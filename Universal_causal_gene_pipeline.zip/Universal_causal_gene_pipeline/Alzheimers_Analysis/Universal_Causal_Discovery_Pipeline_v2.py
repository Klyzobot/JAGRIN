"""
Universal Causal Gene Discovery Pipeline (Version 2.0)
Developed for robust, disease-agnostic causal inference using RNA-seq data.

This pipeline performs:
1. Automated Expression Matrix Construction
2. Differential Expression Analysis (with BH-FDR)
3. Jackknife Statistical Validation (Leave-One-Out or Delete-d)
4. Borda Count Hub Aggregation
5. Protein-Protein Interaction (PPI) Network Analysis
6. Pathway Enrichment (GO, KEGG, Reactome)
7. Gene Regulatory Network Inference (ExtraTreesRegressor)
8. Master Regulator TF Activity Scoring (DecoupleR + BH-FDR)
9. Automated Cell Type Association
10. Comprehensive HTML & JSON Report Generation
"""

import os
import sys
import json
import time
import argparse
import warnings
import urllib3
import requests
import concurrent.futures
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import seaborn as sns
import base64
from io import BytesIO
from datetime import datetime
from multiprocessing import cpu_count
from scipy.stats import ttest_ind, mannwhitneyu
from statsmodels.stats.multitest import multipletests
from sklearn.ensemble import ExtraTreesRegressor
import decoupler as dc

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore")

# Version Information
PIPELINE_VERSION = "2.0"

# Global Config
ARGS = None
START_TIME = None
SUMMARY_DATA = {}

def log(message):
    """Prints a message to console and saves it to a persistent run log."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    formatted_msg = f"[{timestamp}] {message}"
    if ARGS and getattr(ARGS, 'verbose', True):
        print(formatted_msg)
    
    if ARGS and getattr(ARGS, 'output', None):
        log_path = os.path.join(ARGS.output, "run_log.txt")
        if os.path.exists(ARGS.output):
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(formatted_msg + "\\n")

class ArgsMock:
    pass

def parse_arguments():
    if len(sys.argv) > 1:
        parser = argparse.ArgumentParser(description="Universal Causal Gene Discovery Pipeline v2.0")
        parser.add_argument("--name", required=True, help="Name of the disease or project (e.g., NAFLD)")
        parser.add_argument("--disease", required=True, help="Path to Disease CSV count matrix")
        parser.add_argument("--healthy", required=True, help="Path to Healthy CSV count matrix")
        parser.add_argument("--output", default="./outputs", help="Output directory path")
        parser.add_argument("--threads", type=int, default=min(cpu_count(), 4), help="Number of CPU threads to use")
        parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")
        return parser.parse_args()
    else:
        print("=" * 60)
        print("   Universal Causal Gene Discovery Pipeline (Interactive)")
        print("=" * 60)
        args = ArgsMock()
        args.name = input("Enter the Disease Name (e.g., NAFLD, DMD): ").strip()
        args.disease = input("Enter the absolute path to the Disease expression file (CSV/TSV/TXT): ").strip().strip('"')
        args.healthy = input("Enter the absolute path to the Healthy/Baseline expression file (CSV/TSV/TXT): ").strip().strip('"')
        
        args.output = os.path.join("./outputs", args.name)
        
        args.threads = min(cpu_count(), 4)
        args.verbose = True
        return args

def _parse_tcga_file(fpath):
    filename = os.path.basename(fpath)
    try:
        df = pd.read_csv(fpath, sep='\\t' if not filename.endswith(".csv") else ',', comment='#')
        if 'gene_name' in df.columns and 'unstranded' in df.columns:
            df = df.iloc[4:] # Skip TCGA headers
            gene_counts = dict(zip(df['gene_name'], df['unstranded']))
            return filename.split('.')[0], gene_counts
    except:
        pass
    return None, None

def read_expression_file(filepath):
    if os.path.isdir(filepath):
        log(f"\\n[INFO] Directory detected at {filepath}. Attempting to parse as TCGA/Loose files...")
        file_paths = []
        for root, _, files in os.walk(filepath):
            for filename in files:
                if filename.endswith(".tsv") or filename.endswith(".txt") or filename.endswith(".csv"):
                    file_paths.append(os.path.join(root, filename))
                    
        all_data = {}
        if file_paths:
            # Use multi-threading to bypass I/O bottlenecks and speed up loading 100x
            threads = getattr(ARGS, 'threads', 4) if ARGS else 4
            with concurrent.futures.ThreadPoolExecutor(max_workers=threads * 2) as executor:
                for sample_id, gene_counts in executor.map(_parse_tcga_file, file_paths):
                    if sample_id:
                        all_data[sample_id] = gene_counts
                        
        if not all_data:
            log(f"[FATAL ERROR] Could not find or parse valid TCGA files in folder {filepath}")
            sys.exit(1)
            
        merged_df = pd.DataFrame(all_data)
        merged_df.index.name = "Gene"
        # Reset index so 'Gene' becomes the first column, matching CSV format
        return merged_df.reset_index()
        
    if not os.path.isfile(filepath):
        log(f"\\n[FATAL ERROR] The path provided does not exist: {filepath}")
        sys.exit(1)
        
    if filepath.endswith('.tsv') or filepath.endswith('.txt'):
        return pd.read_csv(filepath, sep='\\t')
    return pd.read_csv(filepath)

def step1_build_expression_matrix():
    log("\\n" + "="*50)
    log("[INFO] STEP 1: Building Expression Matrix")
    
    df_disease = read_expression_file(ARGS.disease)
    df_healthy = read_expression_file(ARGS.healthy)
    
    gene_col_d = df_disease.columns[0]
    gene_col_h = df_healthy.columns[0]
    
    df_disease = df_disease.rename(columns={gene_col_d: "Gene"})
    df_healthy = df_healthy.rename(columns={gene_col_h: "Gene"})
    
    # Merge
    merged = pd.merge(df_healthy, df_disease, on="Gene", how="inner")
    
    # Deduplicate
    merged = merged.drop_duplicates(subset=["Gene"]).dropna()
    merged.set_index("Gene", inplace=True)
    
    num_healthy = len(df_healthy.columns) - 1
    num_disease = len(df_disease.columns) - 1
    
    SUMMARY_DATA["Disease"] = ARGS.name
    SUMMARY_DATA["Healthy Samples"] = num_healthy
    SUMMARY_DATA["Disease Samples"] = num_disease
    SUMMARY_DATA["Total Samples"] = num_healthy + num_disease
    SUMMARY_DATA["Genes Analyzed"] = len(merged)
    
    log(f"[INFO] Merged matrix: {num_healthy} Healthy vs {num_disease} Disease samples.")
    log(f"[INFO] Total intersecting genes: {len(merged)}")
    
    # Ensembl Translation
    if any(str(x).startswith("ENSG") for x in merged.index[:10]):
        log("[INFO] Detected Ensembl IDs. Translating to HGNC...")
        ensembl_ids = list(merged.index)
        chunk_size = 1000
        mapping = {}
        for i in range(0, len(ensembl_ids), chunk_size):
            chunk = ensembl_ids[i:i+chunk_size]
            try:
                res = requests.post('https://mygene.info/v3/query', data={'q': ','.join(chunk), 'scopes': 'ensembl.gene', 'fields': 'symbol', 'species': 'human'}, verify=False).json()
                for match in res:
                    if 'symbol' in match and 'query' in match:
                        mapping[match['query']] = match['symbol']
            except:
                pass
        
        merged.index = merged.index.map(lambda x: mapping.get(x, x))
        merged = merged.groupby(merged.index).mean()
        log(f"[SUCCESS] Translated {len(mapping)} genes to HGNC.")
    
    out_dir = os.path.join(ARGS.output, "01_Expression_Matrix")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "expression_matrix.csv")
    merged.to_csv(out_path)
    
    return merged, num_healthy, num_disease

def step2_differential_expression(matrix, num_healthy, num_disease):
    log("\\n" + "="*50)
    log("[INFO] STEP 2: Differential Expression Analysis (DEA)")
    
    healthy_cols = matrix.columns[:num_healthy]
    disease_cols = matrix.columns[num_healthy:]
    
    healthy_means = matrix[healthy_cols].mean(axis=1)
    disease_means = matrix[disease_cols].mean(axis=1)
    
    # Log2FC calculation (+1 pseudocount)
    log2fc = np.log2((disease_means + 1) / (healthy_means + 1))
    
    p_values = []
    # Baseline Mann-Whitney U for standard reporting
    for i in range(len(matrix)):
        h_vals = matrix[healthy_cols].iloc[i].values
        d_vals = matrix[disease_cols].iloc[i].values
        try:
            stat, p = mannwhitneyu(d_vals, h_vals, alternative='two-sided')
            p_values.append(p if not np.isnan(p) else 1.0)
        except:
            p_values.append(1.0)
            
    # Benjamini-Hochberg FDR
    _, fdr_p, _, _ = multipletests(p_values, method='fdr_bh')
    
    dea_df = pd.DataFrame({
        "Gene": matrix.index,
        "Disease_Mean": disease_means.values,
        "Healthy_Mean": healthy_means.values,
        "Log2FC": log2fc.values,
        "Raw_P_Value": p_values,
        "Adjusted_P_Value": fdr_p
    })
    
    out_dir = os.path.join(ARGS.output, "02_Differential_Expression")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "dea_results.csv")
    dea_df.to_csv(out_path, index=False)
    
    log(f"[SUCCESS] DEA complete. Evaluated {len(dea_df)} genes with BH-FDR correction.")
    return dea_df

def step3_and_4_jackknife(matrix, dea, num_healthy, num_disease):
    log("\\n" + "="*50)
    log("[INFO] STEP 3 & 4: Jackknife Statistical Validation")
    
    total_samples = num_healthy + num_disease
    drop_count_h = max(1, int(num_healthy * 0.1))
    drop_count_d = max(1, int(num_disease * 0.1))
    
    if total_samples < 150:
        log(f"[INFO] N={total_samples} < 150. Triggering Leave-One-Out Jackknife ({total_samples} iterations).")
        iterations = total_samples
        drop_count_h = 1
        drop_count_d = 1
    else:
        log(f"[INFO] N={total_samples} >= 150. Triggering 10% Delete-d Jackknife.")
        iterations = 100
        
    healthy_cols = matrix.columns[:num_healthy]
    disease_cols = matrix.columns[num_healthy:]
    
    # Pre-filter by Log2FC > 1.5 for computational speed in Jackknife
    candidates = dea[dea["Log2FC"].abs() > 1.5]["Gene"].tolist()
    log(f"[INFO] Prefiltered {len(candidates)} genes with |Log2FC| > 1.5 for rigorous Jackknife.")
    
    if len(candidates) == 0:
        log("[WARNING] No genes passed Log2FC > 1.5. Proceeding with top 500 by FC.")
        candidates = dea.sort_values(by="Log2FC", key=abs, ascending=False).head(500)["Gene"].tolist()
    
    jackknife_p_matrix = []
    
    # Pre-extract numpy matrix to avoid 150,000 slow Pandas .loc calls
    cand_matrix = matrix.loc[candidates]
    
    for i in range(iterations):
        if total_samples < 150: # Leave-One-Out mode
            h_keep = healthy_cols.drop(healthy_cols[i]) if i < num_healthy else healthy_cols
            d_keep = disease_cols.drop(disease_cols[i - num_healthy]) if i >= num_healthy else disease_cols
            if len(h_keep) == 0: h_keep = healthy_cols
            if len(d_keep) == 0: d_keep = disease_cols
        else: # 10% Delete-d mode
            h_keep = np.random.choice(healthy_cols, num_healthy - drop_count_h, replace=False)
            d_keep = np.random.choice(disease_cols, num_disease - drop_count_d, replace=False)
            
        # Slice pandas once per iteration, then use pure numpy
        h_mat = cand_matrix[h_keep].values
        d_mat = cand_matrix[d_keep].values
            
        iter_p = []
        for j in range(len(candidates)):
            try:
                stat, p = mannwhitneyu(d_mat[j], h_mat[j], alternative='two-sided')
                iter_p.append(p if not np.isnan(p) else 1.0)
            except:
                iter_p.append(1.0)
        jackknife_p_matrix.append(iter_p)
        
    # Aggregate P-values using MEDIAN
    jackknife_p_matrix = np.array(jackknife_p_matrix)
    median_p_values = np.median(jackknife_p_matrix, axis=0)
    
    # Benjamini-Hochberg FDR on the aggregated median P-values
    _, fdr_p, _, _ = multipletests(median_p_values, method='fdr_bh')
    
    stable_df = pd.DataFrame({
        "Gene": candidates,
        "Median_Jackknife_P_Value": median_p_values,
        "Adjusted_P_Value": fdr_p
    })
    
    stable_df = pd.merge(stable_df, dea[["Gene", "Log2FC"]], on="Gene", how="left")
    stable_genes = stable_df[stable_df["Adjusted_P_Value"] < 0.05].sort_values("Adjusted_P_Value")
    
    if len(stable_genes) == 0:
        log("[WARNING] No genes passed FDR < 0.05. Using top 100 by Median P-Value.")
        stable_genes = stable_df.sort_values("Median_Jackknife_P_Value").head(100)
    
    SUMMARY_DATA["Stable Genes"] = len(stable_genes)
    log(f"[INFO] Discovered {len(stable_genes)} mathematically stable causal drivers.")
    
    out_dir = os.path.join(ARGS.output, "03_Jackknife_Stability")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "stable_genes.csv")
    stable_genes.to_csv(out_path, index=False)
    
    return stable_genes

def step5_ppi_network(stable_genes):
    log("\\n" + "="*50)
    log("[INFO] STEP 5: Protein-Protein Interaction (STRING DB & Borda Count)")
    genes = stable_genes["Gene"].tolist()[:300]
    
    out_dir = os.path.join(ARGS.output, "04_PPI_Network")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "ppi_centrality.csv")
    
    try:
        url = "https://string-db.org/api/json/network"
        params = {"identifiers": "%0d".join(genes), "species": 9606, "required_score": 400}
        res = requests.post(url, data=params, verify=False).json()
        
        G = nx.Graph()
        for edge in res:
            G.add_edge(edge["preferredName_A"], edge["preferredName_B"], weight=edge["score"])
            
        deg = nx.degree_centrality(G)
        bet = nx.betweenness_centrality(G)
        try:
            eig = nx.eigenvector_centrality(G, max_iter=1000)
        except:
            eig = {n: 0.0 for n in G.nodes()}
            
        df = pd.DataFrame({
            "Gene": list(G.nodes()),
            "Degree_Centrality": [deg.get(n, 0) for n in G.nodes()],
            "Betweenness_Centrality": [bet.get(n, 0) for n in G.nodes()],
            "Eigenvector_Centrality": [eig.get(n, 0) for n in G.nodes()]
        })
        
        df["Degree_Rank"] = df["Degree_Centrality"].rank(ascending=False, method="min")
        df["Betweenness_Rank"] = df["Betweenness_Centrality"].rank(ascending=False, method="min")
        df["Eigenvector_Rank"] = df["Eigenvector_Centrality"].rank(ascending=False, method="min")
        
        # Borda Count Aggregation
        # Borda score = Rank(Degree) + Rank(Betweenness) + Rank(Eigenvector)
        # Lower score = better hub
        df["Borda_Count_Rank"] = df[["Degree_Rank", "Betweenness_Rank", "Eigenvector_Rank"]].mean(axis=1)
        
        df = df.sort_values("Borda_Count_Rank", ascending=True).reset_index(drop=True)
        df.to_csv(out_path, index=False)
        
        SUMMARY_DATA["Hub Genes"] = len(df[df["Borda_Count_Rank"] <= 20])
        log(f"[SUCCESS] PPI Network analyzed using Borda Count. Saved to {out_path}")
        return df, G
    except Exception as e:
        log(f"[ERROR] STRING DB failed: {e}")
        return pd.DataFrame({"Gene": genes}), nx.Graph()

def step5b_pathway_enrichment(stable_genes):
    log("\\n" + "="*50)
    log("[INFO] STEP 5b: Pathway Enrichment (GO, KEGG, Reactome)")
    # Filter out unmapped ENSEMBL/LOC/LINC genes that destroy the hypergeometric P-value
    valid_genes = [g for g in stable_genes["Gene"].tolist() if not (str(g).startswith("ENSG") or str(g).startswith("LOC") or str(g).startswith("LINC"))]
    genes = valid_genes[:500]
    
    if len(genes) == 0:
        log("[WARNING] No mapped protein-coding genes left for Pathway Enrichment.")
        return {}
        
    genes_str = "\n".join(genes)
    
    out_dir = os.path.join(ARGS.output, "05b_Pathway_Enrichment")
    os.makedirs(out_dir, exist_ok=True)
    
    databases = ["GO_Biological_Process_2023", "KEGG_2021_Human", "Reactome_2022"]
    
    try:
        # Add list to Enrichr
        add_url = "https://maayanlab.cloud/Enrichr/addList"
        payload = {'list': (None, genes_str), 'description': (None, 'Pipeline_v2_Stable_Genes')}
        res = requests.post(add_url, files=payload, verify=False).json()
        user_list_id = res["userListId"]
        
        enrichment_results = {}
        
        for db in databases:
            query_url = f"https://maayanlab.cloud/Enrichr/enrich?userListId={user_list_id}&backgroundType={db}"
            res_db = requests.get(query_url, verify=False).json()
            
            records = []
            for item in res_db[db]:
                # item format: [Rank, Term, P-value, Z-score, Combined Score, Overlapping Genes, Adjusted P-value, Old P-value, Old Adjusted P-value]
                term = item[1]
                adj_p = item[6]
                comb_score = item[4]
                overlap_genes = ";".join(item[5])
                records.append({"Term": term, "Adjusted_P_Value": adj_p, "Combined_Score": comb_score, "Genes": overlap_genes})
            
            if not records:
                df = pd.DataFrame(columns=["Term", "Adjusted_P_Value", "Combined_Score", "Genes"])
            else:
                df = pd.DataFrame(records)
            df = df[df["Adjusted_P_Value"] < 0.05].sort_values("Adjusted_P_Value")
                
            df.to_csv(os.path.join(out_dir, f"{db.lower()}_enrichment.csv"), index=False)
            enrichment_results[db] = df
            log(f"[INFO] {db}: Found {len(df)} enriched terms.")
            
        SUMMARY_DATA["Top KEGG"] = enrichment_results["KEGG_2021_Human"].iloc[0]["Term"] if not enrichment_results["KEGG_2021_Human"].empty else "None"
        log("[SUCCESS] Pathway Enrichment Complete.")
        return enrichment_results
    except Exception as e:
        log(f"[ERROR] Enrichr Pathway API failed: {e}")
        return None

def step6_grn_inference(matrix, ppi_results):
    log("\\n" + "="*50)
    log("[INFO] STEP 6: Gene Regulatory Network (GRN) Inference (GENIE3)")
    
    try:
        import io
        url = "https://zenodo.org/records/8192729/files/CollecTRI_regulons.csv?download=1"
        res = requests.get(url, verify=False)
        net = pd.read_csv(io.StringIO(res.text))
        tfs = net['source'].unique().tolist()
    except Exception as e:
        log(f"[WARNING] Could not load CollecTRI network: {e}")
        tfs = []
        
    hub_genes = ppi_results.head(300)["Gene"].tolist()
    matrix_genes = matrix.index.tolist()
    
    tf_list = list(set(tfs) & set(matrix_genes))
    target_list = list(set(hub_genes) & set(matrix_genes))
    
    if len(tf_list) == 0:
        log("[FATAL ERROR] 0 TFs matched between the matrix and the TF database. Cannot infer GRN.")
        sys.exit(1)
        
    if len(tf_list) > 200:
        tf_list = tf_list[:200]
        
    log(f"[INFO] Running ExtraTrees models for {len(target_list)} Targets using {len(tf_list)} TFs...")
    
    X = matrix.loc[tf_list].T
    Y = matrix.loc[target_list].T
    
    edges = []
    threads = getattr(ARGS, 'threads', 1) if ARGS else 1
    
    for i, target in enumerate(target_list):
        if (i+1) % 25 == 0:
            log(f"       -> Processed {i+1}/{len(target_list)} targets...")
            
        model = ExtraTreesRegressor(n_estimators=1000, max_features="sqrt", n_jobs=threads, random_state=42)
        model.fit(X, Y[target])
        
        importances = model.feature_importances_
        for j, tf in enumerate(tf_list):
            if tf != target and importances[j] > 0.01:
                edges.append({"source": tf, "target": target, "weight": importances[j]})
                
    edges_df = pd.DataFrame(edges).sort_values("weight", ascending=False)
    
    out_dir = os.path.join(ARGS.output, "06_GRN_Inference")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "regulatory_network.csv")
    edges_df.to_csv(out_path, index=False)
    log(f"[SUCCESS] Inferred {len(edges_df)} regulatory edges. Saved to {out_path}")
    return edges_df

def step7_tf_activity(matrix, grn_results, num_healthy, num_disease):
    log("\\n" + "="*50)
    log("[INFO] STEP 7: TF Activity Analysis (CollecTRI & Welch's T-Test)")
    
    try:
        import io
        url = "https://zenodo.org/records/8192729/files/CollecTRI_regulons.csv?download=1"
        res = requests.get(url, verify=False)
        net = pd.read_csv(io.StringIO(res.text))
        
        log("[INFO] Running Decoupler ULM Inference...")
        tf_acts, pvals = dc.mt.ulm(data=matrix.T, net=net, verbose=False)
        
        healthy_cols = tf_acts.index[:num_healthy]
        disease_cols = tf_acts.index[num_healthy:]
        
        results = []
        p_values = []
        
        for tf in tf_acts.columns:
            h_vals = tf_acts.loc[healthy_cols, tf]
            d_vals = tf_acts.loc[disease_cols, tf]
            
            try:
                stat, p = ttest_ind(d_vals, h_vals, equal_var=False)
                p_values.append(p if not np.isnan(p) else 1.0)
            except:
                stat = 0.0
                p = 1.0
                p_values.append(1.0)
                
            results.append({
                "TF": tf,
                "Disease_Mean_Activity": d_vals.mean(),
                "Healthy_Mean_Activity": h_vals.mean(),
                "Activity_Difference": d_vals.mean() - h_vals.mean(),
                "T_Statistic": stat,
                "Raw_P_Value": p
            })
            
        # Benjamini-Hochberg FDR
        _, fdr_p, _, _ = multipletests(p_values, method='fdr_bh')
        
        for i, res in enumerate(results):
            res["Adjusted_P_Value"] = fdr_p[i]
            
        tf_df = pd.DataFrame(results).dropna()
        
        out_dir = os.path.join(ARGS.output, "07_TF_Activity")
        os.makedirs(out_dir, exist_ok=True)
        
        tf_df.to_csv(os.path.join(out_dir, "tf_scores_all.csv"), index=False)
        
        # Sort by absolute T-statistic for Top Master Regulators
        tf_df["Abs_T"] = tf_df["T_Statistic"].abs()
        top_tfs = tf_df.sort_values("Abs_T", ascending=False).drop(columns=["Abs_T"]).head(50)
        
        top_tfs.to_csv(os.path.join(out_dir, "top_master_regulators.csv"), index=False)
        SUMMARY_DATA["Master Regulators"] = len(tf_df[tf_df["Adjusted_P_Value"] < 0.05])
        
        log(f"[SUCCESS] Evaluated {len(tf_df)} TFs with BH-FDR. Saved to {out_dir}")
        return top_tfs
    except Exception as e:
        log(f"[FATAL ERROR] TF Activity failed: {e}")
        sys.exit(1)

def step8_cell_type_association(top_tfs):
    log("\\n" + "="*50)
    log("[INFO] STEP 8: Automated Cell Type Discovery (Enrichr PanglaoDB)")
    
    if top_tfs.empty or "TF" not in top_tfs.columns:
        log("[WARNING] No valid Transcription Factors found from Step 7. Skipping Cell Type Discovery.")
        return
        
    tfs = top_tfs["TF"].tolist()[:50]
    genes_str = "\n".join(tfs)
    
    out_dir = os.path.join(ARGS.output, "08_Cell_Type_Association")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "cell_associations.csv")
    
    try:
        add_url = "https://maayanlab.cloud/Enrichr/addList"
        payload = {'list': (None, genes_str), 'description': (None, 'Pipeline_v2_TFs')}
        res = requests.post(add_url, files=payload, verify=False).json()
        
        query_url = f"https://maayanlab.cloud/Enrichr/enrich?userListId={res['userListId']}&backgroundType=PanglaoDB_Augmented_2021"
        res_db = requests.get(query_url, verify=False).json()
        
        records = []
        for item in res_db.get("PanglaoDB_Augmented_2021", []):
            records.append({"Cell_Type": item[1], "Adjusted_P_Value": item[6], "Combined_Score": item[4]})
            
        if not records:
            df = pd.DataFrame(columns=["Cell_Type", "Adjusted_P_Value", "Combined_Score"])
        else:
            df = pd.DataFrame(records)
            df = df[df["Adjusted_P_Value"] < 0.05].sort_values("Adjusted_P_Value")
            
        df.to_csv(out_path, index=False)
        
        SUMMARY_DATA["Cell Types"] = len(df[df["Adjusted_P_Value"] < 0.05])
        log(f"[SUCCESS] Discovered {len(df)} cell types. Saved to {out_path}")
    except Exception as e:
        log(f"[ERROR] Cell Type API failed: {e}")

def generate_reports():
    log("\\n" + "="*50)
    log("[INFO] Generating Final Reports...")
    
    # Run Metadata
    metadata = {
        "Pipeline_Version": PIPELINE_VERSION,
        "Date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Execution_Time_Seconds": round(time.time() - START_TIME, 2),
        "Parameters": vars(ARGS)
    }
    with open(os.path.join(ARGS.output, "run_metadata.json"), "w") as f:
        json.dump(metadata, f, indent=4)
        
    SUMMARY_DATA["Runtime"] = f"{metadata['Execution_Time_Seconds']}s"
    with open(os.path.join(ARGS.output, "pipeline_summary.json"), "w") as f:
        json.dump(SUMMARY_DATA, f, indent=4)
        
    # Generate simple HTML Report Base
    html = f"""
    <html>
    <head><title>Universal Pipeline v2 Report - {ARGS.name}</title></head>
    <body style="font-family: Arial, sans-serif; margin: 40px;">
        <h1>Universal Causal Gene Discovery Pipeline (v{PIPELINE_VERSION})</h1>
        <h2>Disease: {ARGS.name}</h2>
        <h3>Execution Summary</h3>
        <ul>
            <li>Total Samples: {SUMMARY_DATA.get('Total Samples', 0)}</li>
            <li>Stable Genes: {SUMMARY_DATA.get('Stable Genes', 0)}</li>
            <li>Significant Master Regulators (FDR < 0.05): {SUMMARY_DATA.get('Master Regulators', 0)}</li>
            <li>Top KEGG Pathway: {SUMMARY_DATA.get('Top KEGG', 'None')}</li>
        </ul>
        <p><i>Full results and statistical distributions are available in the CSV outputs.</i></p>
    </body>
    </html>
    """
    with open(os.path.join(ARGS.output, "pipeline_report.html"), "w") as f:
        f.write(html)
        
    log("[SUCCESS] JSON Summaries and HTML Report generated.")

if __name__ == "__main__":
    ARGS = parse_arguments()
    START_TIME = time.time()
    
    os.makedirs(ARGS.output, exist_ok=True)
    
    log(f"\\n{'='*70}\\nUNIVERSAL CAUSAL DISCOVERY PIPELINE v{PIPELINE_VERSION}\\n{'='*70}")
    log(f"Disease Name: {ARGS.name}")
    log(f"Disease File: {ARGS.disease}")
    log(f"Healthy File: {ARGS.healthy}")
    log(f"Output Dir:   {ARGS.output}")
    log(f"Threads:      {ARGS.threads}\\n")
    
    matrix, n_h, n_d = step1_build_expression_matrix()
    dea = step2_differential_expression(matrix, n_h, n_d)
    stable_genes = step3_and_4_jackknife(matrix, dea, n_h, n_d)
    ppi_res, G = step5_ppi_network(stable_genes)
    step5b_pathway_enrichment(stable_genes)
    grn = step6_grn_inference(matrix, ppi_res)
    tfs = step7_tf_activity(matrix, grn, n_h, n_d)
    step8_cell_type_association(tfs)
    
    generate_reports()
    log("\\n[SUCCESS] PIPELINE V2 FULLY EXECUTED!")
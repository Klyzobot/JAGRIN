"""
Universal Causal Gene Discovery Pipeline (Advanced Mathematical Release)
Re-engineered to natively implement strict Mann-Whitney U testing, 
Borda Count centrality, GENIE3 inverted ML inference, and Welch's T-Test validation.
"""

import os
import sys
import pandas as pd
import numpy as np
import networkx as nx
import requests
import urllib3
import time
from scipy.stats import ttest_ind, mannwhitneyu
from sklearn.ensemble import ExtraTreesRegressor
import decoupler as dc
import warnings
from datetime import datetime

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore")

# Set random seed for strict academic reproducibility (Jackknife & ML)
np.random.seed(42)

# ==========================================================
# UNIVERSAL PIPELINE CONFIGURATION
# ==========================================================
DISEASE_NAME = None
DISEASE_FOLDER = None
HEALTHY_FOLDER = None
OUTPUT_DIR = None
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DETAILED_MODE = False
REQUIRE_USER_CONFIRMATION = True
# ==========================================================


def log(message):
    """Prints a message to console and saves it to a persistent run log with a timestamp."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    formatted_msg = f"[{timestamp}] {message}"
    print(formatted_msg)
    
    log_path = os.path.join(OUTPUT_DIR, "run_log.txt")
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(formatted_msg + "\n")


def confirm(message):
    """Prompts the user to continue if manual confirmation is enabled."""
    if not REQUIRE_USER_CONFIRMATION:
        return
        
    while True:
        ans = input(f"\n[WAITING] {message} (Y/N): ").strip().upper()
        if ans == "Y": 
            return
        if ans == "N":
            log("[WARNING] Pipeline terminated by user.")
            sys.exit()
        print("Please enter Y or N.")


def make_step_dir(step_name):
    """Creates a subfolder for a specific pipeline step and returns its path."""
    path = os.path.join(OUTPUT_DIR, step_name)
    os.makedirs(path, exist_ok=True)
    return path


def step1_build_expression_matrix():
    log("\n" + "="*50)
    log("[INFO] STEP 1: Building Expression Matrix")
    
    step_dir = make_step_dir("01_Expression_Matrix")
    out_path = os.path.join(step_dir, "expression_matrix.csv")
    
    if os.path.exists(out_path):
        log(f"[SUCCESS] Checkpoint found! Loading existing matrix from {out_path}")
        return pd.read_csv(out_path).drop_duplicates(subset=["gene_name"]).reset_index(drop=True)

    def parse_folder(path, sample_prefix):
        if os.path.isfile(path):
            sep = "," if path.endswith(".csv") else "\t"
            df = pd.read_csv(path, sep=sep)
            if "gene_name" not in df.columns:
                df.rename(columns={df.columns[0]: "gene_name"}, inplace=True)
            new_cols = {c: f"{sample_prefix}_{c}" for c in df.columns if c != "gene_name"}
            df.rename(columns=new_cols, inplace=True)
            return df

        files_found = []
        file_type = "unknown"
        for root, dirs, files in os.walk(path):
            for file in files:
                if file.endswith(".tsv") and "star" in file:
                    files_found.append(os.path.join(root, file))
                    file_type = "STAR"
                elif file == "quant.sf":
                    files_found.append(os.path.join(root, file))
                    file_type = "Salmon"
                elif file == "abundance.tsv":
                    files_found.append(os.path.join(root, file))
                    file_type = "Kallisto"
                    
        if not files_found:
            return None
            
        log(f"[INFO] Auto-detected {len(files_found)} {file_type} files in {path}")
        gene_col = "gene_name" if file_type == "STAR" else ("Name" if file_type == "Salmon" else "target_id")
        
        merged_df = None
        target_col, metric_used = None, None
        
        for i, file_path in enumerate(files_found):
            skip = 1 if file_type == "STAR" else 0
            df = pd.read_csv(file_path, sep="\t", skiprows=skip)
            
            if target_col is None:
                df_cols = [c.lower() for c in df.columns]
                if file_type == "STAR":
                    if "tpm_unstranded" in df_cols: target_col, metric_used = "tpm_unstranded", "TPM"
                    elif "unstranded" in df_cols: target_col, metric_used = "unstranded", "RAW"
                elif file_type == "Salmon":
                    if "tpm" in df_cols: target_col, metric_used = "TPM", "TPM"
                elif file_type == "Kallisto":
                    if "tpm" in df_cols: target_col, metric_used = "tpm", "TPM"
                log(f"[INFO] Using {metric_used} (Column: {target_col})")
            
            df = df[df[gene_col].notna()].drop_duplicates(subset=[gene_col]).reset_index(drop=True)
            df["gene_name"] = df[gene_col].apply(lambda x: str(x).split('.')[0]) if file_type != "STAR" else df[gene_col]
                
            if merged_df is None:
                if "gene_type" in df.columns:
                    merged_df = df[["gene_name", "gene_type"]].copy()
                else:
                    merged_df = df[["gene_name"]].copy()
                    merged_df["gene_type"] = "unknown"
            merged_df[f"{sample_prefix}_{i+1}"] = df[target_col].values
            
        if metric_used == "RAW":
            numeric_cols = merged_df.select_dtypes(include=[np.number]).columns
            merged_df[numeric_cols] = merged_df[numeric_cols].apply(lambda x: (x / x.sum()) * 1e6)
            
        return merged_df

    disease_df = parse_folder(DISEASE_FOLDER, "Disease")
    healthy_df = parse_folder(HEALTHY_FOLDER, "Healthy")
    
    log("[INFO] Merging Disease and Healthy matrices...")
    expression_df = pd.merge(disease_df, healthy_df, on="gene_name", how="inner")
    expression_df.fillna(0, inplace=True)
    
    disease_cols = [c for c in expression_df.columns if c.startswith("Disease_")]
    healthy_cols = [c for c in expression_df.columns if c.startswith("Healthy_")]
    log(f"[INFO] Processed Total Disease Samples: {len(disease_cols)}")
    log(f"[INFO] Processed Total Healthy Samples: {len(healthy_cols)}")
    
    if expression_df["gene_name"].str.startswith("ENSG").any():
        log("[INFO] Detected Ensembl IDs! Translating to HGNC Gene Symbols via MyGene.info API...")
        try:
            import requests
            ensg_list = expression_df["gene_name"].tolist()
            chunk_size = 1000
            symbol_map = {}
            for i in range(0, len(ensg_list), chunk_size):
                chunk = ensg_list[i:i+chunk_size]
                res = requests.post("https://mygene.info/v3/query", 
                                    data={'q': ','.join(chunk), 'scopes': 'ensembl.gene', 'fields': 'symbol', 'species': 'human'}, 
                                    verify=False).json()
                for match in res:
                    if "symbol" in match:
                        symbol_map[match["query"]] = match["symbol"]
            
            expression_df["gene_name"] = expression_df["gene_name"].map(lambda x: symbol_map.get(x, x))
            
            # Drop any duplicates that mapping might have created (e.g. multiple ENSG mapping to same symbol)
            expression_df = expression_df.groupby("gene_name").mean().reset_index()
            log(f"[SUCCESS] Successfully mapped {len(symbol_map)} Ensembl IDs to Gene Symbols.")
        except Exception as e:
            log(f"[WARNING] Ensembl ID mapping failed: {e}. Proceeding with raw IDs.")
        
    expression_df.to_csv(out_path, index=False)
    log(f"[SUCCESS] Matrix built and saved to {out_path}")
    return expression_df


def step2_differential_expression(matrix):
    log("\n" + "="*50)
    log("[INFO] STEP 2: Differential Expression Analysis (DEA)")
    
    step_dir = make_step_dir("02_Differential_Expression")
    out_path = os.path.join(step_dir, "dea_results.csv")
    
    if os.path.exists(out_path):
        log(f"[SUCCESS] Checkpoint found! Loading DEA from {out_path}")
        return pd.read_csv(out_path).drop_duplicates(subset=["gene_name"]).reset_index(drop=True)

    disease_cols = [c for c in matrix.columns if c.startswith("Disease_")]
    healthy_cols = [c for c in matrix.columns if c.startswith("Healthy_")]
    
    matrix["Disease_Mean"] = matrix[disease_cols].mean(axis=1)
    matrix["Healthy_Mean"] = matrix[healthy_cols].mean(axis=1)
    
    matrix["Fold_Change"] = (matrix["Disease_Mean"] + 0.01) / (matrix["Healthy_Mean"] + 0.01)
    matrix["Log2FC"] = np.log2(matrix["Fold_Change"])
    
    dea_results = matrix.copy().sort_values("Log2FC", ascending=False).reset_index(drop=True)
    dea_results.to_csv(out_path, index=False)
    log(f"[SUCCESS] Processed DEA. Saved to {out_path}")
    return dea_results


def step3_and_4_jackknife(matrix, dea_results):
    log("\n" + "="*50)
    log("[INFO] STEP 3 & 4: Jackknife Statistical Validation")
    
    step_dir = make_step_dir("03_Jackknife_Stability")
    out_path = os.path.join(step_dir, "stable_genes.csv")
    
    if os.path.exists(out_path):
        log(f"[SUCCESS] Checkpoint found! Loading Jackknife results from {out_path}")
        return pd.read_csv(out_path)

    disease_cols = [c for c in matrix.columns if c.startswith("Disease_")]
    healthy_cols = [c for c in matrix.columns if c.startswith("Healthy_")]
    
    genes = matrix["gene_name"].values
    n_genes = len(genes)
    
    total_samples = len(disease_cols) + len(healthy_cols)
    if total_samples < 150:
        iterations = total_samples
        jackknife_type = "Leave-One-Out"
    else:
        iterations = 50
        jackknife_type = "Delete-d (10%)"
        
    log(f"[INFO] Executing {iterations} rigorous {jackknife_type} Jackknife iterations (Mann-Whitney U, Log2FC > 2, P < 0.05)...")
    
    Ranks = np.full((n_genes, iterations), np.nan, dtype=np.float32)
    Scores = np.full((n_genes, iterations), np.nan, dtype=np.float32)
    Log2FC_arr = np.full((n_genes, iterations), np.nan, dtype=np.float32)
    P_Values_arr = np.full((n_genes, iterations), np.nan, dtype=np.float32)
    Passed_Filter = np.zeros((n_genes, iterations), dtype=bool)

    d_mat = matrix[disease_cols].values
    h_mat = matrix[healthy_cols].values
    
    for i in range(iterations):
        if jackknife_type == "Leave-One-Out":
            if i < len(disease_cols):
                sub_d = [j for j in range(len(disease_cols)) if j != i]
                sub_h = list(range(len(healthy_cols)))
            else:
                h_idx = i - len(disease_cols)
                sub_d = list(range(len(disease_cols)))
                sub_h = [j for j in range(len(healthy_cols)) if j != h_idx]
        else:
            sub_d = np.random.choice(d_mat.shape[1], max(1, int(d_mat.shape[1]*0.9)), replace=False)
            sub_h = np.random.choice(h_mat.shape[1], max(1, int(h_mat.shape[1]*0.9)), replace=False)
        
        d_sub = d_mat[:, sub_d]
        h_sub = h_mat[:, sub_h]
        
        d_mean = d_sub.mean(axis=1)
        h_mean = h_sub.mean(axis=1)
        log2fc = np.log2((d_mean + 1e-6) / (h_mean + 1e-6))
        
        p_values = np.ones(n_genes)
        try:
            _, p_values = mannwhitneyu(d_sub, h_sub, alternative="two-sided", axis=1)
        except:
            for g_idx in range(n_genes):
                try:
                    _, p = mannwhitneyu(d_sub[g_idx], h_sub[g_idx], alternative="two-sided")
                    p_values[g_idx] = p
                except:
                    p_values[g_idx] = 1.0
                    
        passed = (d_mean > 1.0) & (log2fc > 2.0) & (p_values < 0.05)
        score = log2fc * (-np.log10(p_values + 1e-300))
        
        Passed_Filter[:, i] = passed
        Scores[:, i] = score
        Log2FC_arr[:, i] = log2fc
        P_Values_arr[:, i] = p_values
        
        temp_df = pd.DataFrame({"Score": score})
        temp_df["Rank"] = temp_df["Score"].rank(ascending=False, method="min")
        Ranks[:, i] = temp_df["Rank"].values

    if DETAILED_MODE:
        log("[INFO] [DETAILED MODE] Saving full Jackknife iterations raw matrix...")
        raw_df = pd.DataFrame({"gene_name": genes})
        for i in range(iterations):
            raw_df[f"Iter_{i+1}_PValue"] = P_Values_arr[:, i]
            raw_df[f"Iter_{i+1}_Log2FC"] = Log2FC_arr[:, i]
            raw_df[f"Iter_{i+1}_Passed"] = Passed_Filter[:, i]
        raw_df.to_csv(os.path.join(step_dir, "jackknife_raw_pvalues_all.csv"), index=False)

    log("[INFO] Calculating Composite Stability Scores (Borda Count)...")
    summary_df = pd.DataFrame({"gene_name": genes})
    if "gene_type" in matrix.columns:
        summary_df["gene_type"] = matrix["gene_type"].values
    summary_df["Mean_Rank"] = np.nanmean(Ranks, axis=1)
    summary_df["Rank_SD"] = np.nanstd(Ranks, axis=1, ddof=1)
    summary_df["Mean_Score"] = np.nanmean(Scores, axis=1)
    summary_df["Mean_Log2FC"] = np.nanmean(Log2FC_arr, axis=1)
    summary_df["Top10_Frequency"] = np.sum(Ranks <= 10, axis=1)
    summary_df["Passed_Filter_Frequency"] = np.sum(Passed_Filter, axis=1)
    
    norm_mean_rank = (summary_df["Mean_Rank"] - summary_df["Mean_Rank"].min()) / (summary_df["Mean_Rank"].max() - summary_df["Mean_Rank"].min() + 1e-9)
    norm_rank_sd = (summary_df["Rank_SD"] - summary_df["Rank_SD"].min()) / (summary_df["Rank_SD"].max() - summary_df["Rank_SD"].min() + 1e-9)
    norm_top10 = summary_df["Top10_Frequency"] / iterations
    norm_filter = summary_df["Passed_Filter_Frequency"] / iterations
    norm_score = (summary_df["Mean_Score"] - summary_df["Mean_Score"].min()) / (summary_df["Mean_Score"].max() - summary_df["Mean_Score"].min() + 1e-9)
    
    summary_df["Composite_Stability_Score"] = (
        0.30 * (1 - norm_mean_rank) +
        0.20 * (1 - norm_rank_sd) +
        0.20 * norm_top10 +
        0.20 * norm_filter +
        0.10 * norm_score
    )
    
    summary_df = summary_df.dropna(subset=["Composite_Stability_Score"])
    summary_df = summary_df.sort_values(by="Composite_Stability_Score", ascending=False).reset_index(drop=True)
    summary_df.to_csv(out_path, index=False)
    log(f"[SUCCESS] Jackknife validated successfully. Saved to {out_path}")
    return summary_df


def step5_ppi_network(stable_genes):
    log("\n" + "="*50)
    log("[INFO] STEP 5: Protein-Protein Interaction (STRING DB & Borda Count)")
    
    step_dir = make_step_dir("04_PPI_Network")
    out_path = os.path.join(step_dir, "ppi_centrality.csv")
    
    if os.path.exists(out_path):
        log(f"[SUCCESS] Checkpoint found! Loading existing PPI network from {out_path}")
        return pd.read_csv(out_path)

    if stable_genes.empty:
        return pd.DataFrame()

    if "gene_type" in stable_genes.columns:
        pc_genes = stable_genes[stable_genes["gene_type"] == "protein_coding"]
        if not pc_genes.empty:
            stable_genes = pc_genes
            
    genes = stable_genes["gene_name"].head(300).tolist()
    url = "https://string-db.org/api/json/network"
    params = {"identifiers": "\r".join(genes), "species": 9606, "required_score": 700}
    
    log("[INFO] Querying STRING DB API...")
    try:
        response = requests.post(url, data=params, verify=False)
        data = response.json()
        
        G = nx.Graph()
        for g in genes: G.add_node(g)
        for edge in data:
            if G.has_node(edge["preferredName_A"]) and G.has_node(edge["preferredName_B"]):
                G.add_edge(edge["preferredName_A"], edge["preferredName_B"], weight=edge["score"])
                
        if DETAILED_MODE:
            log("[INFO] [DETAILED MODE] Saving raw STRING API JSON response...")
            import json
            with open(os.path.join(step_dir, "string_db_raw_response.json"), "w") as f:
                json.dump(data, f, indent=4)
                
            log("[INFO] [DETAILED MODE] Generating Interactive HTML Network (pyvis)...")
            try:
                from pyvis.network import Network
                net = Network(height="750px", width="100%", bgcolor="#222222", font_color="white", notebook=False)
                net.from_nx(G)
                net.save_graph(os.path.join(step_dir, "ppi_network_interactive.html"))
            except Exception as e:
                log(f"[WARNING] Could not generate pyvis network: {e}")
                
        log("[INFO] Calculating Graph Centralities...")
        deg = nx.degree_centrality(G)
        bet = nx.betweenness_centrality(G)
        try:
            eig = nx.eigenvector_centrality(G, max_iter=1000)
        except:
            eig = {n: 0.0 for n in G.nodes()}
            
        df = pd.DataFrame({
            "gene_name": list(G.nodes()),
            "Degree_Centrality": [deg.get(n, 0) for n in G.nodes()],
            "Betweenness_Centrality": [bet.get(n, 0) for n in G.nodes()],
            "Eigenvector_Centrality": [eig.get(n, 0) for n in G.nodes()]
        })
        
        df["Degree_Rank"] = df["Degree_Centrality"].rank(ascending=False, method="min")
        df["Betweenness_Rank"] = df["Betweenness_Centrality"].rank(ascending=False, method="min")
        df["Eigenvector_Rank"] = df["Eigenvector_Centrality"].rank(ascending=False, method="min")
        df["Combined_Rank_Score"] = df[["Degree_Rank", "Betweenness_Rank", "Eigenvector_Rank"]].mean(axis=1)
        
        df = df.sort_values("Combined_Rank_Score", ascending=True).reset_index(drop=True)
        df.to_csv(out_path, index=False)
        log(f"[SUCCESS] PPI Network analyzed. Saved to {out_path}")
        return df
    except Exception as e:
        log(f"[ERROR] STRING DB failed: {e}")
        return pd.DataFrame({"gene_name": genes})


def step6_grn_inference(matrix, ppi_results):
    log("\n" + "="*50)
    log("[INFO] STEP 6: Gene Regulatory Network (GRN) Inference (GENIE3)")
    
    step_dir = make_step_dir("05_GRN_Inference")
    out_path = os.path.join(step_dir, "regulatory_network.csv")
    
    if os.path.exists(out_path):
        log(f"[SUCCESS] Checkpoint found! Loading existing GRN from {out_path}")
        return pd.read_csv(out_path)

    log("[INFO] Downloading human transcription factors list from Aerts Lab...")
    TF_LIST_URL = "https://resources.aertslab.org/cistarget/tf_lists/allTFs_hg38.txt"
    try:
        response = requests.get(TF_LIST_URL, verify=False, timeout=15)
        tf_list = [tf.strip() for tf in response.text.splitlines() if tf.strip() and not tf.startswith("#")]
    except:
        tf_list = ["AR", "FOXA1", "MYC", "ERG", "TP53", "NKX3-1", "SPOP", "E2F1"]

    top_genes = set(ppi_results["gene_name"].head(500).tolist())
    active_tfs = [tf for tf in tf_list if tf in top_genes]
    if len(active_tfs) == 0:
        all_genes = set(matrix["gene_name"].tolist())
        active_tfs = [tf for tf in tf_list if tf in all_genes]
        top_genes.update(active_tfs[:50])

    df_filtered = matrix[matrix["gene_name"].isin(top_genes)].copy()
    sample_cols = [c for c in matrix.columns if c.startswith("Disease_") or c.startswith("Healthy_")]
    
    expression_matrix = df_filtered.groupby("gene_name")[sample_cols].mean().T.astype(np.float32)
    
    final_tfs = [tf for tf in active_tfs if tf in expression_matrix.columns]
    targets = [gene for gene in expression_matrix.columns]
    
    X = expression_matrix[final_tfs].values
    grn_links = []
    
    log(f"[INFO] Running ExtraTrees model: {len(final_tfs)} TFs predicting {len(targets)} Targets...")
    for idx, target in enumerate(targets):
        y = expression_matrix[target].values
        
        # PREVENT DATA LEAKAGE: Remove self-regulation
        if target in final_tfs:
            tf_idx = final_tfs.index(target)
            X_temp = np.delete(X, tf_idx, axis=1)
            temp_tfs = [tf for tf in final_tfs if tf != target]
        else:
            X_temp = X
            temp_tfs = final_tfs
            
        reg = ExtraTreesRegressor(n_estimators=100, max_features="sqrt", n_jobs=-1, random_state=42)
        reg.fit(X_temp, y)
        importances = reg.feature_importances_
        
        for tf, imp in zip(temp_tfs, importances):
            if imp > 0.0:
                grn_links.append({"TF": tf, "Target": target, "Weight": float(imp)})

    network_df = pd.DataFrame(grn_links)
    network_df = network_df.sort_values(by="Weight", ascending=False).reset_index(drop=True)
    network_df.to_csv(out_path, index=False)
    
    if DETAILED_MODE:
        log("[INFO] [DETAILED MODE] Saving GRN TF-Targets Map...")
        top_edges = network_df[network_df["Weight"] > 0.005]
        tf_map = top_edges.groupby("TF")["Target"].apply(lambda x: ", ".join(x)).reset_index()
        tf_map.rename(columns={"Target": "Predicted_Targets"}, inplace=True)
        tf_map.to_csv(os.path.join(step_dir, "grn_tf_targets_map.csv"), index=False)
    log(f"[SUCCESS] Inferred {len(network_df)} regulatory edges. Saved to {out_path}")
    return network_df


def step7_tf_activity(matrix, grn_results):
    log("\n" + "="*50)
    log("[INFO] STEP 7: TF Activity Analysis (CollecTRI & Welch's T-Test)")
    
    step_dir = make_step_dir("06_TF_Activity")
    out_path = os.path.join(step_dir, "tf_scores.csv")
    
    if os.path.exists(out_path):
        log(f"[SUCCESS] Checkpoint found! Loading existing TF Activity from {out_path}")
        return pd.read_csv(out_path)

    sample_cols = [c for c in matrix.columns if c.startswith("Disease_") or c.startswith("Healthy_")]
    mat = matrix.groupby("gene_name")[sample_cols].mean().T.astype(np.float32)
    
    COLLECTRI_URL = "https://zenodo.org/records/8192729/files/CollecTRI_regulons.csv?download=1"
    LOCAL_COLLECTRI = os.path.join(OUTPUT_DIR, "CollecTRI_regulons.csv")
    
    if not os.path.exists(LOCAL_COLLECTRI):
        log("[INFO] Downloading CollecTRI master network from Zenodo...")
        response = requests.get(COLLECTRI_URL, verify=False, timeout=30)
        with open(LOCAL_COLLECTRI, "wb") as f:
            f.write(response.content)
            
    collectri = pd.read_csv(LOCAL_COLLECTRI)
    
    log("[INFO] Running Decoupler ULM Inference...")
    try:
        tf_acts, _ = dc.mt.ulm(data=mat, net=collectri, tmin=5)
    except AttributeError:
        tf_acts, _ = dc.run_ulm(mat=mat, net=collectri, source="source", target="target", weight="weight", min_n=5)
        
    if DETAILED_MODE:
        log("[INFO] [DETAILED MODE] Saving raw DecoupleR ULM Enrichment matrix...")
        tf_acts.to_csv(os.path.join(step_dir, "decoupler_raw_ulm_matrix.csv"))
        
    disease_samples = [s for s in tf_acts.index if s.startswith("Disease_")]
    healthy_samples = [s for s in tf_acts.index if s.startswith("Healthy_")]
    
    tf_results = []
    log("[INFO] Performing Welch's T-Test for Tumor vs Normal Master Regulators...")
    for tf in tf_acts.columns:
        d_vals = tf_acts.loc[disease_samples, tf].values
        h_vals = tf_acts.loc[healthy_samples, tf].values
        
        if d_vals.var() == 0 and h_vals.var() == 0: continue
            
        stat, pval = ttest_ind(d_vals, h_vals, equal_var=False)
        tf_results.append({
            "TF": tf,
            "Disease_Mean_Activity": d_vals.mean(),
            "Healthy_Mean_Activity": h_vals.mean(),
            "Activity_Difference": d_vals.mean() - h_vals.mean(),
            "T_Statistic": stat,
            "P_Value": pval
        })
        
    df = pd.DataFrame(tf_results).dropna().sort_values("P_Value").reset_index(drop=True)
    df.to_csv(out_path, index=False)
    
    # NEW: Create a combined absolute ranking (mix of up and down regulated)
    df['Abs_T'] = df['T_Statistic'].abs()
    combined_df = df.sort_values(by="Abs_T", ascending=False).drop(columns=['Abs_T'])
    combined_out_file = os.path.join(step_dir, "top_master_regulators_combined.csv")
    combined_df.to_csv(combined_out_file, index=False)
    
    log(f"[SUCCESS] Evaluated {len(df)} Master Regulators. Saved to {out_path} and {combined_out_file}")
    return df


def step8_cell_type_association(matrix, tf_results):
    log("\n" + "="*50)
    log("[INFO] STEP 8: Automated Cell Type Discovery (Enrichr API)")
    
    step_dir = make_step_dir("07_Cell_Type_Association")
    out_path = os.path.join(step_dir, "cell_associations.csv")
    
    if os.path.exists(out_path):
        return pd.read_csv(out_path)

    if tf_results.empty: return pd.DataFrame()

    top_tfs = tf_results["TF"].head(50).tolist()
    log(f"[INFO] Submitting {len(top_tfs)} Master Regulators to Enrichr PanglaoDB...")
    
    try:
        add_url = "https://maayanlab.cloud/Enrichr/addList"
        response = requests.post(add_url, files={'list': (None, "\n".join(top_tfs))}, verify=False)
        user_list_id = response.json()['userListId']
        
        query_url = f"https://maayanlab.cloud/Enrichr/enrich?userListId={user_list_id}&backgroundType=PanglaoDB_Augmented_2021"
        enrichment = requests.get(query_url, verify=False).json().get("PanglaoDB_Augmented_2021", [])
        
        results = [{"Cell_Type": t[1], "P_Value": t[2], "Adjusted_P_Value": t[6]} for t in enrichment if t[2] < 0.05]
        df = pd.DataFrame(results).sort_values("P_Value")
        df.to_csv(out_path, index=False)
        log(f"[SUCCESS] Discovered {len(df)} cell types. Saved to {out_path}")
        return df
    except Exception as e:
        log(f"[ERROR] Enrichr API failed: {e}")
        return pd.DataFrame()


if __name__ == "__main__":
    print("=" * 50)
    print("  UNIVERSAL CAUSAL DISCOVERY PIPELINE  ")
    print("=" * 50)
    
    # Interactive Prompts
    DISEASE_NAME = input("Enter the Disease Name (e.g., Alzheimers): ").strip()
    DISEASE_FOLDER = input("Enter the path to the Disease data folder or CSV: ").strip()
    HEALTHY_FOLDER = input("Enter the path to the Healthy data folder or CSV: ").strip()
    
    mode_input = input("Do you want [1] Simple Output or [2] Detailed Output? ").strip()
    if mode_input == "2":
        DETAILED_MODE = True
        print("[INFO] Detailed Mode Enabled: Massive raw intermediate logs will be saved.")
    else:
        DETAILED_MODE = False
        print("[INFO] Simple Mode Enabled: Standard output summaries will be saved.")
        
    OUTPUT_DIR = os.path.join(BASE_DIR, f"{DISEASE_NAME}_Output")
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    with open(os.path.join(OUTPUT_DIR, "run_log.txt"), "a") as f:
        f.write(f"\n\n{'='*70}\nNEW RUN INITIATED: {DISEASE_NAME}\n{'='*70}\n")
        
    log(f"[INFO] Starting Universal Pipeline for: {DISEASE_NAME}")
    
    expr_matrix = step1_build_expression_matrix()
    confirm("Step 1 complete. Continue to Differential Expression?")
    
    dea = step2_differential_expression(expr_matrix)
    confirm("Step 2 complete. Continue to Jackknife Validation?")
    
    stable = step3_and_4_jackknife(expr_matrix, dea)
    confirm("Jackknife Validation complete. Continue to PPI Network?")
    
    ppi = step5_ppi_network(stable)
    confirm("PPI Network complete. Continue to GRN Inference?")
    
    grn = step6_grn_inference(expr_matrix, ppi)
    confirm("GRN Inference complete. Continue to TF Activity?")
    
    tf = step7_tf_activity(expr_matrix, grn)
    confirm("TF Activity complete. Continue to Cell Type Association?")
    
    step8_cell_type_association(expr_matrix, tf)
    
    log("\n" + "="*50)
    log(f"[SUCCESS] PIPELINE FULLY EXECUTED!")
    log(f"[INFO] All mathematically verified results saved in: {OUTPUT_DIR}")

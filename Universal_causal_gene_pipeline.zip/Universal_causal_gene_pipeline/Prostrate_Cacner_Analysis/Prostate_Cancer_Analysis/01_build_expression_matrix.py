import os
import re
import sys
import glob
import pandas as pd
from datetime import datetime

# ==========================================================
# CONFIGURATION
# ==========================================================

# Cancer dataset root
CANCER_FOLDER = r"C:\Users\B NAVANEETH"

# Normal dataset root
NORMAL_FOLDER = r"C:\Users\B NAVANEETH\Downloads\gdc_download_20260612_060956.190660"

# Output folder
OUTPUT_FOLDER = r"C:\Prostate_Cancer_Analysis\Output"

os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# UUID pattern used by GDC folders
UUID_PATTERN = re.compile(
    r'^[0-9a-fA-F]{8}-'
    r'[0-9a-fA-F]{4}-'
    r'[0-9a-fA-F]{4}-'
    r'[0-9a-fA-F]{4}-'
    r'[0-9a-fA-F]{12}$'
)

print("=" * 70)
print("TCGA Expression Matrix Generator")
print("=" * 70)

def confirm(message):

    while True:

        ans = input(f"\n{message} (Y/N): ").strip().upper()

        if ans == "Y":
            return True

        if ans == "N":
            print("\nProgram terminated by user.")
            sys.exit()

        print("Please enter Y or N.")

print("\nSTEP 1 : Scanning Cancer Dataset\n")

cancer_files = []

invalid = []

for folder in sorted(os.listdir(CANCER_FOLDER)):

    folder_path = os.path.join(CANCER_FOLDER, folder)

    if not os.path.isdir(folder_path):
        continue

    if folder.lower() == "downloads":
        continue

    if folder.startswith("."):
        continue

    if not UUID_PATTERN.match(folder):
        continue

    star = glob.glob(
        os.path.join(
            folder_path,
            "*.rna_seq.augmented_star_gene_counts.tsv"
        )
    )

    if len(star) == 1:
        cancer_files.append(star[0])

    else:
        invalid.append(folder)

print("Cancer Samples Found :", len(cancer_files))
print("Invalid UUID folders :", len(invalid))

confirm("Continue to Normal Dataset?")

# ==========================================================
# STEP 2 : SCAN NORMAL DATASET
# ==========================================================

print("\n" + "=" * 70)
print("STEP 2 : SCANNING NORMAL DATASET")
print("=" * 70)

normal_files = []

for folder in sorted(os.listdir(NORMAL_FOLDER)):

    folder_path = os.path.join(NORMAL_FOLDER, folder)

    if not os.path.isdir(folder_path):
        continue

    star = glob.glob(
        os.path.join(
            folder_path,
            "*.rna_seq.augmented_star_gene_counts.tsv"
        )
    )

    if len(star) == 1:
        normal_files.append(star[0])

print("\nNormal Samples Found :", len(normal_files))

print("\nFirst Five Normal Samples:\n")

for f in normal_files[:5]:
    print(f)

confirm("Continue to Dataset Validation?")

# ==========================================================
# STEP 3 : VALIDATE DATASET
# ==========================================================

print("\n" + "=" * 70)
print("STEP 3 : VALIDATING DATASET")
print("=" * 70)

all_files = cancer_files + normal_files

reference_gene_id = None
reference_gene_name = None
reference_gene_type = None

corrupted_files = []

for index, file in enumerate(all_files, start=1):

    try:

        df = pd.read_csv(file, sep="\t", skiprows=1)

        # Remove STAR summary rows
        df = df[df["gene_name"].notna()].reset_index(drop=True)

        required_columns = [
            "gene_id",
            "gene_name",
            "gene_type",
            "tpm_unstranded"
        ]

        missing = [c for c in required_columns if c not in df.columns]

        if missing:
            print(f"\nMissing columns in:\n{file}")
            print(missing)
            corrupted_files.append(file)
            continue

        if reference_gene_id is None:

            reference_gene_id = df["gene_id"]
            reference_gene_name = df["gene_name"]
            reference_gene_type = df["gene_type"]

        else:

            if not reference_gene_id.equals(df["gene_id"]):
                raise Exception("Gene IDs do not match")

            if not reference_gene_name.equals(df["gene_name"]):
                raise Exception("Gene Names do not match")

            if not reference_gene_type.equals(df["gene_type"]):
                raise Exception("Gene Types do not match")

        if index % 25 == 0:
            print(f"Validated {index}/{len(all_files)} files")

    except Exception as e:

        print(f"\nValidation Failed:\n{file}")
        print(e)

        corrupted_files.append(file)

print("\nValidation Completed")

print("Valid Files :", len(all_files) - len(corrupted_files))
print("Corrupted Files :", len(corrupted_files))

if len(corrupted_files) > 0:

    print("\nCorrupted Files List:")

    for f in corrupted_files:
        print(f)

    print("\nPlease fix corrupted files before proceeding.")

    sys.exit()

confirm("Dataset validated successfully. Continue to build expression matrix?")

# ==========================================================
# STEP 4 : BUILD EXPRESSION MATRIX
# ==========================================================

print("\n" + "=" * 70)
print("STEP 4 : BUILDING EXPRESSION MATRIX")
print("=" * 70)

expression_df = None
sample_information = []

processed = 0

# ----------------------------
# Process Cancer Samples
# ----------------------------

for i, file in enumerate(cancer_files, start=1):

    df = pd.read_csv(file, sep="\t", skiprows=1)

    df = df[df["gene_name"].notna()].reset_index(drop=True)

    sample_name = f"Tumor_{i:03d}"

    if expression_df is None:

        expression_df = df[
            ["gene_id", "gene_name", "gene_type"]
        ].copy()

    expression_df[sample_name] = df["tpm_unstranded"].values

    sample_information.append({
        "Sample": sample_name,
        "Type": "Tumor",
        "Original_File": file
    })

    processed += 1

    if processed % 25 == 0:
        print(f"Processed {processed}/{len(all_files)}")


# ----------------------------
# Process Normal Samples
# ----------------------------

for i, file in enumerate(normal_files, start=1):

    df = pd.read_csv(file, sep="\t", skiprows=1)

    df = df[df["gene_name"].notna()].reset_index(drop=True)

    sample_name = f"Normal_{i:03d}"

    expression_df[sample_name] = df["tpm_unstranded"].values

    sample_information.append({
        "Sample": sample_name,
        "Type": "Normal",
        "Original_File": file
    })

    processed += 1

    if processed % 25 == 0 or processed == len(all_files):
        print(f"Processed {processed}/{len(all_files)}")

print("\nExpression Matrix Created Successfully!")

print("\nMatrix Shape:")
print(expression_df.shape)

print("\nFirst Five Columns:")
print(expression_df.columns[:8].tolist())

confirm("Continue to Quality Control?")

# ==========================================================
# STEP 5 : QUALITY CONTROL
# ==========================================================

print("\n" + "=" * 70)
print("STEP 5 : QUALITY CONTROL")
print("=" * 70)

total_genes = len(expression_df)
total_samples = len(sample_information)
tumor_samples = len(cancer_files)
normal_samples = len(normal_files)

missing_values = expression_df.isnull().sum().sum()
duplicate_gene_ids = expression_df["gene_id"].duplicated().sum()
duplicate_gene_names = expression_df["gene_name"].duplicated().sum()

print(f"Total Genes              : {total_genes}")
print(f"Tumor Samples            : {tumor_samples}")
print(f"Normal Samples           : {normal_samples}")
print(f"Total Samples            : {total_samples}")
print(f"Missing Values           : {missing_values}")
print(f"Duplicate Gene IDs       : {duplicate_gene_ids}")
print(f"Duplicate Gene Names     : {duplicate_gene_names}")

print("\nExpression Matrix Shape :", expression_df.shape)

confirm("Save all generated files?")

# ==========================================================
# STEP 6 : SAVE OUTPUT FILES
# ==========================================================

print("\n" + "=" * 70)
print("STEP 6 : SAVING OUTPUT FILES")
print("=" * 70)

expression_csv = os.path.join(
    OUTPUT_FOLDER,
    "expression_matrix.csv"
)

sample_csv = os.path.join(
    OUTPUT_FOLDER,
    "sample_information.csv"
)

summary_txt = os.path.join(
    OUTPUT_FOLDER,
    "dataset_summary.txt"
)

log_txt = os.path.join(
    OUTPUT_FOLDER,
    "expression_matrix.log"
)

print("Saving Expression Matrix...")
expression_df.to_csv(expression_csv, index=False)

print("Saving Sample Information...")
pd.DataFrame(sample_information).to_csv(sample_csv, index=False)

summary = f"""
==========================================================
TCGA PRAD DATASET SUMMARY
==========================================================

Generated On:
{datetime.now()}

Tumor Samples:
{tumor_samples}

Normal Samples:
{normal_samples}

Total Samples:
{total_samples}

Genes:
{total_genes}

Expression Matrix Shape:
{expression_df.shape}

Missing Values:
{missing_values}

Duplicate Gene IDs:
{duplicate_gene_ids}

Duplicate Gene Names:
{duplicate_gene_names}

Expression Column Used:
tpm_unstranded

==========================================================
"""

with open(summary_txt, "w") as f:
    f.write(summary)

log = f"""
Expression Matrix Generation Log

Started Successfully

Generated:
{datetime.now()}

Cancer Files:
{tumor_samples}

Normal Files:
{normal_samples}

Genes:
{total_genes}

Status:
SUCCESS
"""

with open(log_txt, "w") as f:
    f.write(log)

print("\nFiles Generated Successfully!\n")

print(expression_csv)
print(sample_csv)
print(summary_txt)
print(log_txt)

print("\nPipeline Completed Successfully!")
import os
import pandas as pd
import numpy as np

print("=" * 80)
print("PHASE IV: CELL-TYPE ASSOCIATION ANALYSIS")
print("=" * 80)

# ==========================================================
# CONFIGURATION
# ==========================================================
SUMMARY_DIR = r"C:\Prostate_Cancer_Analysis\Output\Jackknife_Parallel\Summary"
MATRIX_FILE = r"C:\Prostate_Cancer_Analysis\Output\expression_matrix.parquet"
TF_ACTIVITY_CSV = os.path.join(SUMMARY_DIR, "tf_activity_results.csv")
OUTPUT_CSV = os.path.join(SUMMARY_DIR, "cell_type_association.csv")

# Focus on top 15 Master Regulators (activated in tumor)
TOP_N_TFS = 15

# ==========================================================
# DEFINE PROSTATE CELL-TYPE MARKERS (FROM scRNA-seq LITERATURE)
# ==========================================================
# Sources: Henry et al. (2018), Karthaus et al. (2014)
cell_markers = {
    "Luminal_Epithelial": ["KLK3", "ACPP", "KRT8", "KRT18", "MSMB"],
    "Basal_Epithelial": ["KRT5", "KRT15", "TP63", "KRT14", "GSTP1"],
    "Stromal_Fibroblast": ["ACTA2", "COL1A1", "MYH11", "TAGLN", "COL1A2"],
    "Endothelial": ["PECAM1", "VWF", "CDH5", "ENG"],
    "Immune": ["PTPRC", "CD3D", "CD14", "CD4", "CD8A"]
}

# ==========================================================
# LOAD DATA
# ==========================================================
if not os.path.exists(TF_ACTIVITY_CSV):
    print(f"[ERROR] Could not find TF activities file at {TF_ACTIVITY_CSV}")
    exit(1)

print("Loading top Master Regulators...")
df_tfs = pd.read_csv(TF_ACTIVITY_CSV)
# Filter for TFs activated in tumor (Activity_Difference > 0)
df_active_tfs = df_tfs[df_tfs["Activity_Difference"] > 0].head(TOP_N_TFS)
top_tfs = df_active_tfs["TF"].tolist()
print(f"Top {len(top_tfs)} Master Regulators to evaluate: {top_tfs}")

print("\nReading expression matrix from Parquet...")
expression_df = pd.read_parquet(MATRIX_FILE)
sample_cols = [c for c in expression_df.columns if c.startswith("Tumor_") or c.startswith("Normal_")]

# Group duplicates and set index to gene_name
df_grouped = expression_df.groupby("gene_name")[sample_cols].mean()

# ==========================================================
# CALCULATE CORRELATION & CELL-TYPE ASSOCIATION
# ==========================================================
print("\nPerforming correlation-based cell-type association...")

# Flatten the list of all marker genes to query from expression matrix
all_markers = [marker for list_markers in cell_markers.values() for marker in list_markers]
# Keep only TFs and markers present in our dataset
available_genes = list(set(top_tfs + all_markers))
available_genes = [g for g in available_genes if g in df_grouped.index]

# Slice matrix for these genes and transpose (samples as rows, genes as columns)
expression_matrix = df_grouped.loc[available_genes].T

# Calculate Spearman correlation matrix (rank correlation is robust to outliers)
print("Calculating Spearman rank correlations across patient cohort...")
corr_matrix = expression_matrix.corr(method="spearman")

# Associate each TF with cell types by averaging correlation with cell-type markers
association_results = []

for tf in top_tfs:
    if tf not in expression_matrix.columns:
        continue
        
    associations = {"TF": tf}
    
    for cell_type, markers in cell_markers.items():
        # Get markers that are available in the dataset
        valid_markers = [m for m in markers if m in expression_matrix.columns and m != tf]
        
        if valid_markers:
            # Calculate average correlation of the TF with all markers of this cell type
            avg_corr = corr_matrix.loc[tf, valid_markers].mean()
            associations[cell_type] = avg_corr
        else:
            associations[cell_type] = np.nan
            
    # Identify the primary associated cell type (highest correlation)
    cell_types_only = {k: v for k, v in associations.items() if k != "TF" and not np.isnan(v)}
    if cell_types_only:
        primary_cell_type = max(cell_types_only, key=cell_types_only.get)
        associations["Primary_Cell_Type"] = primary_cell_type
        associations["Max_Correlation"] = cell_types_only[primary_cell_type]
    else:
        associations["Primary_Cell_Type"] = "None"
        associations["Max_Correlation"] = np.nan
        
    association_results.append(associations)

df_association = pd.DataFrame(association_results)

# Sort by Max Correlation descending
df_association = df_association.sort_values(by="Max_Correlation", ascending=False).reset_index(drop=True)

# Save results
df_association.to_csv(OUTPUT_CSV, index=False)
print(f"Saved cell-type association results to: {OUTPUT_CSV}")

print("\nCell-Type Association Matrix:")
print(df_association.to_string(index=False))

print("\nPHASE IV CELL-TYPE ASSOCIATION COMPLETE!\n")

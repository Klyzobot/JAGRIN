import os
import gc
import time
import random
import traceback
import multiprocessing
import shutil
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
import pandas as pd
import numpy as np
from scipy.stats import mannwhitneyu
from statsmodels.stats.multitest import multipletests
import sys
import scipy
import statsmodels
import json

# =====================================================
# CONFIGURATION
# =====================================================
EXPRESSION_MATRIX_CSV = r"C:\Prostate_Cancer_Analysis\Output\expression_matrix.csv"
EXPRESSION_MATRIX_PARQUET = r"C:\Prostate_Cancer_Analysis\Output\expression_matrix.parquet"

OUTPUT_FOLDER = r"C:\Prostate_Cancer_Analysis\Output\Jackknife_Parallel"
TEST_FOLDER = r"C:\Prostate_Cancer_Analysis\Output\Jackknife_Test"

ITERATIONS = 1000
REMOVAL_PERCENT = 0.10
RANDOM_SEED_BASE = 42

TEST_MODE = False
TEST_ITERATIONS = 5

CHECKPOINT_EVERY = 25

# Globals for workers (initialized once per worker process to save memory/pickling)
gene_info = None
tumor_array = None
normal_array = None
tumor_columns = []
normal_columns = []
gene_ids = None
gene_names = None
gene_types = None
USE_VECTORIZED_MW = False

# Removed custom bh_fdr function in favor of statsmodels

def init_worker(matrix_path):
    """
    Initializer function for each worker process.
    Loads the Parquet file into memory and extracts NumPy arrays for ultra-fast iterations.
    """
    global gene_info, tumor_array, normal_array, tumor_columns, normal_columns
    global gene_ids, gene_names, gene_types, USE_VECTORIZED_MW
    
    # Load via Parquet (3-5x faster than CSV)
    expression_df = pd.read_parquet(matrix_path)
    
    gene_info = expression_df[["gene_id", "gene_name", "gene_type"]].copy()
    gene_ids = gene_info["gene_id"].to_numpy()
    gene_names = gene_info["gene_name"].to_numpy()
    gene_types = gene_info["gene_type"].to_numpy()
    
    tumor_columns = [c for c in expression_df.columns if c.startswith("Tumor_")]
    normal_columns = [c for c in expression_df.columns if c.startswith("Normal_")]
    
    # Store directly as NumPy arrays (eliminates pandas slicing overhead inside the loop)
    tumor_array = expression_df[tumor_columns].values.astype(np.float64)
    normal_array = expression_df[normal_columns].values.astype(np.float64)
    
    # Free memory
    del expression_df
    gc.collect()
    
    # Check if scipy version supports vectorized mannwhitneyu (axis=1)
    try:
        # Dummy test
        mannwhitneyu(np.array([[1, 2], [3, 4]]), np.array([[5, 6], [7, 8]]), axis=1)
        USE_VECTORIZED_MW = True
    except TypeError:
        USE_VECTORIZED_MW = False

def sample_patients(iteration):
    rng = random.Random(RANDOM_SEED_BASE + iteration)
    keep_tumor = int(len(tumor_columns) * (1 - REMOVAL_PERCENT))
    keep_normal = int(len(normal_columns) * (1 - REMOVAL_PERCENT))

    # We sample the column INDICES, which allows lightning-fast numpy slicing
    tumor_indices = rng.sample(range(len(tumor_columns)), keep_tumor)
    normal_indices = rng.sample(range(len(normal_columns)), keep_normal)
    
    return tumor_indices, normal_indices

def perform_dea(sel_tumor_array, sel_normal_array):
    cancer_mean = sel_tumor_array.mean(axis=1)
    normal_mean = sel_normal_array.mean(axis=1)
    cancer_median = np.median(sel_tumor_array, axis=1)
    normal_median = np.median(sel_normal_array, axis=1)
    
    cancer_std = sel_tumor_array.std(axis=1, ddof=0)
    normal_std = sel_normal_array.std(axis=1, ddof=0)
    
    cancer_cv = cancer_std / (cancer_mean + 1e-9)
    normal_cv = normal_std / (normal_mean + 1e-9)
    
    fold_change = (cancer_mean + 1e-6) / (normal_mean + 1e-6)
    log2fc = np.log2(fold_change)

    total = len(sel_tumor_array)
    
    # Extremely fast vectorized Mann-Whitney if supported, otherwise fast numpy loop
    if USE_VECTORIZED_MW:
        try:
            _, p_values = mannwhitneyu(sel_tumor_array, sel_normal_array, alternative="two-sided", axis=1)
        except Exception:
            p_values = np.full(total, np.nan)
    else:
        p_values = np.empty(total)
        for i in range(total):
            try:
                _, p = mannwhitneyu(sel_tumor_array[i], sel_normal_array[i], alternative="two-sided")
                p_values[i] = p
            except Exception:
                p_values[i] = np.nan

    # Calculate Benjamini-Hochberg Adjusted P-Value using statsmodels
    valid_mask = ~np.isnan(p_values)
    adj_p_values = np.full_like(p_values, np.nan)
    if valid_mask.any():
        adj_p_values[valid_mask] = multipletests(p_values[valid_mask], method="fdr_bh")[1]

    # Highly efficient DataFrame creation (avoids .copy() overhead)
    result = pd.DataFrame({
        "gene_id": gene_ids,
        "gene_name": gene_names,
        "gene_type": gene_types,
        "Cancer_Mean": cancer_mean,
        "Normal_Mean": normal_mean,
        "Cancer_Median": cancer_median,
        "Normal_Median": normal_median,
        "Cancer_Std": cancer_std,
        "Normal_Std": normal_std,
        "Cancer_CV": cancer_cv,
        "Normal_CV": normal_cv,
        "Fold_Change": fold_change,
        "Log2FC": log2fc,
        "P_Value": p_values,
        "Adjusted_P_Value": adj_p_values
    })
    
    return result

def rank_genes(dea_df):
    dea_df = dea_df.dropna(subset=["P_Value"]).copy()
    
    # Exact Scientific Filters using Raw P-Value as strictly required
    dea_df["Passed_Filter"] = (
        (dea_df["Cancer_Mean"] > 1) &
        (dea_df["Log2FC"] > 2) &
        (dea_df["P_Value"] < 0.1)
    )
    
    dea_df["Score"] = dea_df["Log2FC"] * (-np.log10(dea_df["P_Value"] + 1e-300))
    dea_df.sort_values(by="Score", ascending=False, inplace=True)
    dea_df.reset_index(drop=True, inplace=True)
    dea_df["Rank"] = dea_df.index + 1
    return dea_df

def run_single_iteration(iteration, output_dir):
    worker_id = multiprocessing.current_process().name
    iteration_start = time.time()
    
    final_save_file = os.path.join(output_dir, f"Iteration_{iteration:04d}.csv.gz")
    tmp_save_file = os.path.join(output_dir, f"Iteration_{iteration:04d}.tmp.gz")
    
    try:
        if os.path.exists(final_save_file):
            try:
                # Robust Validation: Ensure the gzip is readable to avoid skipping corrupt files
                pd.read_csv(final_save_file, nrows=5)
                return {"iteration": iteration, "status": "skipped", "runtime": 0.0, "top_gene": None, "worker_id": worker_id}
            except Exception:
                pass # Proceed to overwrite corrupt file

        # Select indices for this iteration
        tumor_indices, normal_indices = sample_patients(iteration)
        
        # Slicing the numpy arrays (much faster than DataFrame slicing)
        sel_tumor_array = tumor_array[:, tumor_indices]
        sel_normal_array = normal_array[:, normal_indices]

        # Calculate Differential Expression & Ranking
        dea = perform_dea(sel_tumor_array, sel_normal_array)
        ranked = rank_genes(dea)
        ranked["Iteration"] = iteration

        # Verify Schema
        expected_columns = [
            "gene_id", "gene_name", "gene_type",
            "Cancer_Mean", "Normal_Mean", "Cancer_Median", "Normal_Median",
            "Cancer_Std", "Normal_Std", "Cancer_CV", "Normal_CV",
            "Fold_Change", "Log2FC", "P_Value", "Adjusted_P_Value",
            "Passed_Filter", "Score", "Rank", "Iteration"
        ]
        if list(ranked.columns) != expected_columns:
            raise RuntimeError(f"Schema mismatch! Found: {list(ranked.columns)}")

        # ATOMIC WRITING: Save to temp, then rename
        # Removed float_format to preserve tiny p-value precision
        ranked.to_csv(tmp_save_file, index=False, compression="gzip")
        os.replace(tmp_save_file, final_save_file)
        
        kept_tumor_names = [tumor_columns[i] for i in tumor_indices]
        removed_tumor_names = [tumor_columns[i] for i in range(len(tumor_columns)) if i not in tumor_indices]
        
        kept_normal_names = [normal_columns[i] for i in normal_indices]
        removed_normal_names = [normal_columns[i] for i in range(len(normal_columns)) if i not in normal_indices]
        
        iteration_metadata = {
            "iteration": iteration,
            "removed_tumor": removed_tumor_names,
            "removed_normal": removed_normal_names,
            "kept_tumor": kept_tumor_names,
            "kept_normal": kept_normal_names
        }
        
        if not ranked.empty:
            top_row = ranked.iloc[0]
            top_gene_str = f"{top_row['gene_name']} (Score: {top_row['Score']:.2f}, L2FC: {top_row['Log2FC']:.2f}, P: {top_row['P_Value']:.2e})"
        else:
            top_gene_str = "None"
            
        runtime = time.time() - iteration_start

        # Clean up temporary numpy slices to free memory
        del dea, ranked, sel_tumor_array, sel_normal_array
        if iteration % 20 == 0:
            gc.collect()

        return {"iteration": iteration, "status": "success", "runtime": runtime, "top_gene": top_gene_str, "worker_id": worker_id, "metadata": iteration_metadata}
    except Exception as e:
        if os.path.exists(tmp_save_file):
            try:
                os.remove(tmp_save_file)
            except:
                pass
        return {"iteration": iteration, "status": "error", "error_msg": str(e), "trace": traceback.format_exc(), "worker_id": worker_id}

def convert_to_parquet_if_needed():
    if not os.path.exists(EXPRESSION_MATRIX_PARQUET):
        print(f"\n[INIT] Parquet matrix not found. Converting CSV to Parquet for 3-5x faster loading...")
        print(f"[INIT] Reading {EXPRESSION_MATRIX_CSV} (this may take a minute)...")
        df = pd.read_csv(EXPRESSION_MATRIX_CSV)
        print(f"[INIT] Writing to {EXPRESSION_MATRIX_PARQUET}...")
        df.to_parquet(EXPRESSION_MATRIX_PARQUET, index=False)
        print("[INIT] Parquet conversion complete!\n")
        del df
        gc.collect()

if __name__ == '__main__':
    print("=" * 80)
    print("JACKKNIFE BIOMARKER VALIDATION (PARALLEL PRODUCTION VERSION)")
    print("=" * 80)
    
    # 1. Convert CSV to Parquet if needed
    convert_to_parquet_if_needed()
    
    # 2. Setup Mode & Folders
    target_iterations = TEST_ITERATIONS if TEST_MODE else ITERATIONS
    working_output_folder = TEST_FOLDER if TEST_MODE else OUTPUT_FOLDER
    
    if TEST_MODE:
        print("\n*** TEST MODE ENABLED ***")
        if os.path.exists(working_output_folder):
            shutil.rmtree(working_output_folder)
    
    os.makedirs(working_output_folder, exist_ok=True)
    
    # Automatically determine cores
    n_cores_available = multiprocessing.cpu_count()
    N_CORES = n_cores_available
    
    print(f"Total Iterations : {target_iterations}")
    print(f"Removal %        : {REMOVAL_PERCENT * 100}")
    print(f"Base Random Seed : {RANDOM_SEED_BASE}")
    print(f"Cores Available  : {n_cores_available}")
    print(f"Workers Config   : {N_CORES}")
    print(f"Output Folder    : {working_output_folder}")
    print("=" * 80)
    
    overall_start = time.time()
    
    completed_count = 0
    skipped_count = 0
    error_count = 0
    total_runtimes = 0.0
    
    top_gene_buffer = []
    
    iterations_to_run = list(range(1, target_iterations + 1))
    
    executor = None
    # Start process pool with initializer pointing to Parquet
    try:
        with ProcessPoolExecutor(max_workers=N_CORES, initializer=init_worker, initargs=(EXPRESSION_MATRIX_PARQUET,)) as executor:
            print("\nWorkers initialized and loading Parquet data into NumPy arrays. Starting tasks...")
            futures = {executor.submit(run_single_iteration, i, working_output_folder): i for i in iterations_to_run}
            
            for future in as_completed(futures):
                res = future.result()
                iteration = res["iteration"]
                status = res["status"]
                worker_id = res["worker_id"]
                
                if status == "skipped":
                    skipped_count += 1
                    print(f"[{worker_id}] Iteration {iteration:04d}/{target_iterations} SKIPPED (File exists)")
                
                elif status == "success":
                    completed_count += 1
                    total_runtimes += res["runtime"]
                    
                    # Buffer the top gene log
                    top_gene_buffer.append(f"Iteration {iteration} : {res['top_gene']}")
                    
                    # Safely append JSON metadata from the main process
                    with open(os.path.join(working_output_folder, "metadata.jsonl"), "a") as mf:
                        mf.write(json.dumps(res["metadata"]) + "\n")
                    
                    # Calculate True ETA and percentage
                    avg_runtime = total_runtimes / completed_count
                    remaining = target_iterations - (completed_count + skipped_count + error_count)
                    # The ETA is the average runtime times the number of remaining items, divided by the active cores.
                    eta_seconds = (avg_runtime * remaining) / N_CORES
                    percent_complete = (completed_count + skipped_count + error_count) / target_iterations * 100
                    
                    print(f"[{percent_complete:6.2f}%] [{worker_id}] Iteration {iteration:04d}/{target_iterations} | "
                          f"Top Gene: {res['top_gene']:<45} | "
                          f"Runtime: {res['runtime']:5.2f}s | "
                          f"ETA: {eta_seconds/3600:5.2f} hrs")
                    
                    # Checkpointing strictly based on completed count to avoid race conditions
                    if completed_count % CHECKPOINT_EVERY == 0 or completed_count == target_iterations:
                        # Flush checkpoint
                        with open(os.path.join(working_output_folder, f"checkpoint_{completed_count}.txt"), "w") as f:
                            f.write(f"Checkpoint\nCompleted Count: {completed_count}\nTime : {datetime.now()}\n")
                        # Flush top gene history buffer
                        if top_gene_buffer:
                            with open(os.path.join(working_output_folder, "top_gene_history.txt"), "a") as f:
                                f.write("\n".join(top_gene_buffer) + "\n")
                            top_gene_buffer.clear()
                          
                elif status == "error":
                    error_count += 1
                    print(f"[{worker_id}] Iteration {iteration:04d} FAILED: {res['error_msg']}")
                    with open(os.path.join(working_output_folder, "failed_iterations.txt"), "a") as f:
                        f.write(f"\nIteration: {iteration}\nTime: {datetime.now()}\n{res['trace']}\n{'='*40}\n")
                        
            # Flush any remaining buffer
            if top_gene_buffer:
                with open(os.path.join(working_output_folder, "top_gene_history.txt"), "a") as f:
                    f.write("\n".join(top_gene_buffer) + "\n")
                top_gene_buffer.clear()
    except KeyboardInterrupt:
        print("\n[!] KeyboardInterrupt detected. Shutting down workers...")
        if executor is not None:
            executor.shutdown(cancel_futures=True)
        print("Shutdown complete.")

    total_time = time.time() - overall_start
    print("\n" + "=" * 80)
    print("JACKKNIFE VALIDATION PARALLEL COMPLETED")
    print("=" * 80)
    print(f"Total Runtime : {total_time / 3600:.2f} hours")
    print(f"Processed     : {completed_count}")
    print(f"Skipped       : {skipped_count}")
    print(f"Errors        : {error_count}")

    # Get matrix shape stats for logging safely using pyarrow
    try:
        import pyarrow.parquet as pq
        pq_file = pq.ParquetFile(EXPRESSION_MATRIX_PARQUET)
        expr_cols = pq_file.schema.names
        num_tumor = sum(1 for c in expr_cols if c.startswith("Tumor_"))
        num_normal = sum(1 for c in expr_cols if c.startswith("Normal_"))
        num_genes = pq_file.metadata.num_rows
    except:
        num_tumor = num_normal = num_genes = "Unknown"

    # Generate Run Log
    with open(os.path.join(working_output_folder, "run_log.txt"), "w") as f:
        f.write(f"=========================================================\n")
        f.write(f"TCGA PRAD JACKKNIFE RUN LOG (PARALLEL)\n")
        f.write(f"=========================================================\n\n")
        f.write(f"Run Date:\n{datetime.now()}\n\n")
        
        f.write(f"Environment Versions:\n")
        f.write(f" - Python      : {sys.version.split()[0]}\n")
        f.write(f" - Pandas      : {pd.__version__}\n")
        f.write(f" - NumPy       : {np.__version__}\n")
        f.write(f" - SciPy       : {scipy.__version__}\n")
        f.write(f" - Statsmodels : {statsmodels.__version__}\n\n")
        
        f.write(f"Mode:\n{'TEST_MODE' if TEST_MODE else 'PRODUCTION'}\n\n")
        f.write(f"Dataset Details:\n")
        f.write(f" - Tumor Samples : {num_tumor}\n")
        f.write(f" - Normal Samples: {num_normal}\n")
        f.write(f" - Total Genes   : {num_genes}\n\n")
        f.write(f"Iterations:\n{target_iterations}\n\n")
        f.write(f"Removal Percentage:\n{REMOVAL_PERCENT}\n\n")
        f.write(f"Random Seed Base:\n{RANDOM_SEED_BASE}\n\n")
        f.write(f"Filter Criteria:\nRaw P-Value < 0.1, Cancer_Mean > 1, Log2FC > 2\n")
        f.write(f"*(Note: Benjamini-Hochberg Adjusted P-Value calculated for reporting only)*\n\n")
        f.write(f"Cores Used:\n{N_CORES}\n\n")
        f.write(f"Completed Successfully:\n{'YES' if error_count == 0 else 'NO (' + str(error_count) + ' errors)'}\n\n")
        f.write(f"Total Runtime:\n{total_time/3600:.2f} hours\n\n")
        f.write(f"Output Folder:\n{working_output_folder}\n\n")
        f.write(f"=========================================================\n")

    if TEST_MODE and error_count == 0:
        print(f"\n[TEST MODE] All iterations successful. Outputs verified in {TEST_FOLDER}")
        print("[TEST MODE] Folder left intact for inspection.")
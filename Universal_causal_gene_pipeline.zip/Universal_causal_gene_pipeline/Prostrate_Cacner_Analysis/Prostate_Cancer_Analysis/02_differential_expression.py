import pandas as pd
import numpy as np
import os
from glob import glob

# =====================================================
# CHANGE THESE PATHS
# =====================================================

CANCER_FOLDER = r"C:\Users\B NAVANEETH"

NORMAL_FOLDER = r"C:\Users\B NAVANEETH\Downloads\gdc_download_20260612_060956.190660"

# =====================================================

def get_tsv_files(root_folder):
    files = glob(
        os.path.join(root_folder, "**", "*.tsv"),
        recursive=True
    )
    print(len(files))
    return files


def build_expression_matrix(file_list, group_name):

    merged_df = None

    for i, file in enumerate(file_list):

        try:

            df = pd.read_csv(file, sep="\t")

            sample_name = f"{group_name}_{i+1}"

            expr = df[["gene_name", "tpm_unstranded"]].copy()

            expr.columns = ["gene_name", sample_name]

            if merged_df is None:
                merged_df = expr

            else:
                merged_df = merged_df.merge(
                    expr,
                    on="gene_name",
                    how="outer"
                )

        except Exception as e:
            print(f"Error reading {file}")
            print(e)

    merged_df.fillna(0, inplace=True)

    return merged_df


print("Finding files...")

cancer_files = get_tsv_files(CANCER_FOLDER)
normal_files = get_tsv_files(NORMAL_FOLDER)

print("Cancer files:", len(cancer_files))
print("Normal files:", len(normal_files))

print("\nBuilding Cancer Matrix...")

cancer_matrix = build_expression_matrix(
    cancer_files,
    "Cancer"
)

print("\nBuilding Normal Matrix...")

normal_matrix = build_expression_matrix(
    normal_files,
    "Normal"
)

print("\nCalculating Means...")

cancer_matrix["Cancer_Mean"] = (
    cancer_matrix.iloc[:, 1:]
    .mean(axis=1)
)

normal_matrix["Normal_Mean"] = (
    normal_matrix.iloc[:, 1:]
    .mean(axis=1)
)

result = pd.DataFrame()

result["Gene"] = cancer_matrix["gene_name"]

result["Cancer_Mean"] = cancer_matrix["Cancer_Mean"]

result["Normal_Mean"] = normal_matrix["Normal_Mean"]

# Avoid division by zero

result["Fold_Change"] = (
    result["Cancer_Mean"] + 0.01
) / (
    result["Normal_Mean"] + 0.01
)

result["Log2FC"] = np.log2(
    result["Fold_Change"]
)

# Sort by strongest increase

result = result.sort_values(
    by="Log2FC",
    ascending=False
)

print("\nTop 20 Upregulated Genes")

print(
    result[
        ["Gene",
         "Cancer_Mean",
         "Normal_Mean",
         "Log2FC"]
    ].head(20)
)

# Save complete results

output_file = "DEA_results.csv"

result.to_csv(
    output_file,
    index=False
)

print("\nDone!")
print(f"Results saved as {output_file}")
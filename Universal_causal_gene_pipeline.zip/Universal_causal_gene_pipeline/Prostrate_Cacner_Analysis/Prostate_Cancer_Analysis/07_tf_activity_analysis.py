import os
import requests
import urllib3
import pandas as pd
import numpy as np
from scipy.stats import ttest_ind

# Disable urllib3 SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import decoupler as dc

print("=" * 80)
print("PHASE IV: TRANSCRIPTION FACTOR (TF) ACTIVITY & MASTER REGULATOR ANALYSIS")
print("=" * 80)

# ==========================================================
# CONFIGURATION
# ==========================================================
SUMMARY_DIR = r"C:\Prostate_Cancer_Analysis\Output\Jackknife_Parallel\Summary"
MATRIX_FILE = r"C:\Prostate_Cancer_Analysis\Output\expression_matrix.parquet"
OUTPUT_CSV = os.path.join(SUMMARY_DIR, "tf_activity_results.csv")
LOCAL_COLLECTRI_CSV = "CollecTRI_regulons.csv"
COLLECTRI_URL = "https://zenodo.org/records/8192729/files/CollecTRI_regulons.csv?download=1"

# ==========================================================
# LOAD FULL EXPRESSION MATRIX
# ==========================================================
if not os.path.exists(MATRIX_FILE):
    print(f"[ERROR] Could not find expression matrix at {MATRIX_FILE}")
    exit(1)

print("Reading full expression data from Parquet...")
expression_df = pd.read_parquet(MATRIX_FILE)

# Extract sample columns
sample_cols = [c for c in expression_df.columns if c.startswith("Tumor_") or c.startswith("Normal_")]
print(f"Found {len(sample_cols)} patient samples.")

# Transpose matrix so samples are rows and genes are columns
print("Grouping duplicates and transposing matrix for Decoupler (Samples as rows, Genes as columns)...")
df_grouped = expression_df.groupby("gene_name")[sample_cols].mean()
mat = df_grouped.T.astype(np.float32)
print(f"Expression matrix shape: {mat.shape}")

# ==========================================================
# DOWNLOAD COLLECTRI TF-TARGET NETWORK DIRECTLY BYPASSING SSL
# ==========================================================
if not os.path.exists(LOCAL_COLLECTRI_CSV):
    print(f"\nDownloading CollecTRI network directly from Zenodo (Bypassing SSL verification)...")
    try:
        response = requests.get(COLLECTRI_URL, verify=False, timeout=30)
        response.raise_for_status()
        with open(LOCAL_COLLECTRI_CSV, "wb") as f:
            f.write(response.content)
        print("Successfully downloaded CollecTRI regulons database.")
    except Exception as e:
        print(f"[ERROR] Failed to download CollecTRI regulons directly: {e}")
        exit(1)

print(f"\nLoading local CollecTRI network from {LOCAL_COLLECTRI_CSV}...")
try:
    collectri = pd.read_csv(LOCAL_COLLECTRI_CSV)
    print(f"Loaded regulons containing {len(collectri)} TF-target regulations.")
except Exception as e:
    print(f"[ERROR] Failed to load local CollecTRI network: {e}")
    exit(1)

# ==========================================================
# COMPUTE TF ACTIVITIES (ULM METHOD)
# ==========================================================
print("\nRunning Decoupler ULM (Univariate Linear Model) algorithm...")
try:
    # dc.mt.ulm returns a tuple of DataFrames (activities, pvalues)
    tf_acts, tf_pvals = dc.mt.ulm(data=mat, net=collectri, verbose=False)
    print(f"Computed activities for {tf_acts.shape[1]} transcription factors across all samples.")
except Exception as e:
    print(f"[ERROR] Failed to compute TF activities: {e}")
    import traceback
    traceback.print_exc()
    exit(1)

# ==========================================================
# IDENTIFY MASTER REGULATORS (DIFFERENTIAL ACTIVITY)
# ==========================================================
print("\nIdentifying Master Regulators (Tumor vs Normal activity)...")
tumor_samples = [s for s in tf_acts.index if s.startswith("Tumor_")]
normal_samples = [s for s in tf_acts.index if s.startswith("Normal_")]

tf_names = tf_acts.columns
tf_results = []

for tf in tf_names:
    tumor_vals = tf_acts.loc[tumor_samples, tf].values
    normal_vals = tf_acts.loc[normal_samples, tf].values
    
    tumor_mean = np.mean(tumor_vals)
    normal_mean = np.mean(normal_vals)
    diff = tumor_mean - normal_mean
    
    # Perform two-sample t-test (Welch's t-test for unequal variances)
    stat, pval = ttest_ind(tumor_vals, normal_vals, equal_var=False)
    
    tf_results.append({
        "TF": tf,
        "Tumor_Mean_Activity": tumor_mean,
        "Normal_Mean_Activity": normal_mean,
        "Activity_Difference": diff,
        "T_Statistic": stat,
        "P_Value": pval
    })

df_results = pd.DataFrame(tf_results)
df_results = df_results.dropna()

# Sort by P-Value to find the most significantly altered TFs
df_results = df_results.sort_values(by="P_Value").reset_index(drop=True)

# Save results
df_results.to_csv(OUTPUT_CSV, index=False)
print(f"Saved TF activity and Master Regulator results to: {OUTPUT_CSV}")

# Display top 15 Master Regulators (upregulated in cancer)
print("\nTop 15 Tumor-Activated Master Regulators (Diff > 0):")
print(df_results[df_results["Activity_Difference"] > 0].head(15))

# Display top 15 tumor-suppressing TFs (downregulated in cancer)
print("\nTop 15 Tumor-Inactivated TFs (Diff < 0):")
print(df_results[df_results["Activity_Difference"] < 0].head(15))

print("\nPHASE IV TRANSCRIPTION FACTOR & MASTER REGULATOR ANALYSIS COMPLETE!\n")

import os
import requests
import pandas as pd
import numpy as np
import urllib3
import time
from sklearn.ensemble import ExtraTreesRegressor

# Disable urllib3 SSL warnings for download
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==========================================================
# CONFIGURATION
# ==========================================================
SUMMARY_DIR = r"C:\Prostate_Cancer_Analysis\Output\Jackknife_Parallel\Summary"
STABLE_GENES_CSV = os.path.join(SUMMARY_DIR, "stable_protein_coding_genes.csv")
MATRIX_FILE = r"C:\Prostate_Cancer_Analysis\Output\expression_matrix.parquet"
OUTPUT_CSV = os.path.join(SUMMARY_DIR, "grn_boost_results.csv")

TOP_N_GENES = 500  # Number of top stable genes to include in network
TF_LIST_URL = "https://resources.aertslab.org/cistarget/tf_lists/allTFs_hg38.txt"

def main():
    print("=" * 80)
    print("PHASE IV: GENE REGULATORY NETWORK (GRN) INFERENCE (GENIE3 APPROACH)")
    print("=" * 80)
    print("Initializing robust scikit-learn ExtraTreesRegressor for network inference...")

    # ==========================================================
    # DOWNLOAD OR DEFINE TRANSCRIPTION FACTORS
    # ==========================================================
    print("\nDownloading human transcription factors list...")
    tf_list = []
    try:
        response = requests.get(TF_LIST_URL, verify=False, timeout=15)
        response.raise_for_status()
        raw_tfs = response.text.splitlines()
        tf_list = [tf.strip() for tf in raw_tfs if tf.strip() and not tf.startswith("#")]
        print(f"Loaded {len(tf_list)} transcription factors from Aerts Lab.")
    except Exception as e:
        print(f"[WARNING] Failed to download TF list ({e}). Using a fallback curated list.")
        tf_list = [
            "AR", "FOXA1", "MYC", "ERG", "TP53", "NKX3-1", "SPOP", "E2F1", "SOX2", "POU5F1",
            "NANOG", "STAT3", "NFKB1", "RELA", "JUN", "FOS", "CREB1", "HIF1A", "EP300", "CTNNB1",
            "RUNX2", "KLF4", "MYB", "ETV1", "ETV4", "ETV5", "FLI1", "GATA2", "GATA3", "SP1"
        ]

    # ==========================================================
    # LOAD DATA & FILTER EXPRESSION MATRIX
    # ==========================================================
    if not os.path.exists(STABLE_GENES_CSV):
        print(f"[ERROR] Could not find stable genes file at {STABLE_GENES_CSV}")
        return

    print(f"\nLoading top {TOP_N_GENES} stable protein-coding genes...")
    df_genes = pd.read_csv(STABLE_GENES_CSV).head(TOP_N_GENES)
    genes_of_interest = set(df_genes["gene_name"].tolist())

    # Ensure the regulators (TFs) are in our genes of interest if they are active
    active_tfs = [tf for tf in tf_list if tf in genes_of_interest]
    print(f"Identified {len(active_tfs)} active transcription factors within our top stable genes.")

    if len(active_tfs) == 0:
        print("[WARNING] No overlapping TFs found. Expanding search to include any TF in the dataset.")
        expression_df = pd.read_parquet(MATRIX_FILE, columns=["gene_name"])
        all_genes_in_dataset = set(expression_df["gene_name"].tolist())
        active_tfs = [tf for tf in tf_list if tf in all_genes_in_dataset]
        genes_of_interest.update(active_tfs[:50])
        print(f"Added {len(active_tfs[:50])} TFs from dataset to genes of interest.")

    # Load expression data from parquet
    print(f"Reading expression data from {MATRIX_FILE}...")
    expression_df = pd.read_parquet(MATRIX_FILE)
    df_filtered = expression_df[expression_df["gene_name"].isin(genes_of_interest)]

    # Find sample columns
    sample_cols = [c for c in df_filtered.columns if c.startswith("Tumor_") or c.startswith("Normal_")]
    print(f"Found {len(sample_cols)} patient samples.")

    # Transpose matrix so samples are rows and genes are columns
    print("Transposing expression matrix (Samples as rows, Genes as columns)...")
    df_filtered_grouped = df_filtered.groupby("gene_name")[sample_cols].mean()
    expression_matrix = df_filtered_grouped.T.astype(np.float32)

    print(f"Expression matrix shape: {expression_matrix.shape}")

    # Define the regulators list present in our expression matrix columns
    final_tfs = [tf for tf in active_tfs if tf in expression_matrix.columns]
    targets = [gene for gene in expression_matrix.columns]
    
    print(f"Running regulatory model with {len(final_tfs)} regulators against {len(targets)} targets...")

    # ==========================================================
    # RUN GENIE3 (REGULATORY MODEL WITH EXTRATREES)
    # ==========================================================
    start_time = time.time()
    
    # Prepare inputs
    X = expression_matrix[final_tfs].values
    
    grn_links = []
    
    # Run ExtraTrees for each target gene
    for idx, target in enumerate(targets):
        y = expression_matrix[target].values
        
        # If the target gene is also a TF, we remove it from the feature set to avoid self-regulation
        if target in final_tfs:
            tf_idx = final_tfs.index(target)
            X_temp = np.delete(X, tf_idx, axis=1)
            temp_tfs = [tf for tf in final_tfs if tf != target]
        else:
            X_temp = X
            temp_tfs = final_tfs
            
        # Initialize ExtraTreesRegressor
        reg = ExtraTreesRegressor(n_estimators=100, max_features="sqrt", n_jobs=-1, random_state=42)
        reg.fit(X_temp, y)
        
        # Get feature importances
        importances = reg.feature_importances_
        
        # Store links
        for tf, imp in zip(temp_tfs, importances):
            if imp > 0.0:  # Only store positive importance links
                grn_links.append({
                    "TF": tf,
                    "Target": target,
                    "Importance": float(imp)
                })
                
        if (idx + 1) % 50 == 0 or (idx + 1) == len(targets):
            print(f"Completed {idx + 1}/{len(targets)} target genes...")

    # Compile into DataFrame
    network_df = pd.DataFrame(grn_links)
    network_df = network_df.sort_values(by="Importance", ascending=False).reset_index(drop=True)
    
    # Save the output network
    network_df.to_csv(OUTPUT_CSV, index=False)
    print(f"\nGENIE3 successfully completed in {time.time() - start_time:.2f} seconds.")
    print(f"Saved Gene Regulatory Network to: {OUTPUT_CSV}")
    
    print("\nTop 15 Regulatory Interactions (TF -> Target):")
    print(network_df.head(15))
    
    print("\nPHASE IV GRN ANALYSIS COMPLETE!\n")

if __name__ == '__main__':
    main()

import os
import requests
import pandas as pd
import numpy as np
import networkx as nx
from pyvis.network import Network

print("=" * 80)
print("PHASE IV: PROTEIN-PROTEIN INTERACTION (PPI) & HUB GENE ANALYSIS")
print("=" * 80)

# ==========================================================
# CONFIGURATION
# ==========================================================
SUMMARY_DIR = r"C:\Prostate_Cancer_Analysis\Output\Jackknife_Parallel\Summary"
STABLE_GENES_CSV = os.path.join(SUMMARY_DIR, "stable_protein_coding_genes.csv")
OUTPUT_CSV = os.path.join(SUMMARY_DIR, "ppi_centrality_results.csv")
OUTPUT_HTML = os.path.join(SUMMARY_DIR, "ppi_network.html")

TOP_N_GENES = 300  # Number of top stable genes to query
STRING_API_URL = "https://string-db.org/api/json/network"
species_human = 9606  # Species code for Homo sapiens

# ==========================================================
# LOAD DATA & DEFINE REGULATION STATUS
# ==========================================================
if not os.path.exists(STABLE_GENES_CSV):
    print(f"[ERROR] Could not find stable genes file at {STABLE_GENES_CSV}")
    exit(1)

print(f"Loading top {TOP_N_GENES} stable protein-coding genes...")
df_genes = pd.read_csv(STABLE_GENES_CSV).head(TOP_N_GENES)

# Define regulation status (+1 for upregulated, -1 for downregulated, 0 for neutral)
# Upregulated: Mean_Log2FC > 1.0, Downregulated: Mean_Log2FC < -1.0
df_genes["Regulation"] = np.where(df_genes["Mean_Log2FC"] > 1.0, 1,
                         np.where(df_genes["Mean_Log2FC"] < -1.0, -1, 0))

gene_list = df_genes["gene_name"].tolist()
gene_meta = df_genes.set_index("gene_name")

# ==========================================================
# QUERY STRING DATABASE API
# ==========================================================
print("\nQuerying STRING Database API...")
params = {
    "identifiers": "\r".join(gene_list),
    "species": species_human,
    "caller_identity": "prostate_cancer_causal_pipeline",
    "required_score": 700,  # High confidence interactions (>= 0.700)
    "add_nodes": 0          # Do not add shell/interactor nodes (only query genes)
}

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    response = requests.post(STRING_API_URL, data=params, verify=False)
    response.raise_for_status()
    interactions = response.json()
    print(f"Retrieved {len(interactions)} protein-protein interactions from STRING DB.")
except Exception as e:
    print(f"[ERROR] Failed to query STRING API: {e}")
    exit(1)

# ==========================================================
# CONSTRUCT PPI GRAPH
# ==========================================================
print("\nConstructing NetworkX Graph...")
G = nx.Graph()

# Add all query genes as nodes (ensures isolated nodes are kept if they have no edges)
for gene in gene_list:
    reg = int(gene_meta.loc[gene, "Regulation"])
    log2fc = float(gene_meta.loc[gene, "Mean_Log2FC"])
    score = float(gene_meta.loc[gene, "Composite_Stability_Score"])
    G.add_node(gene, regulation=reg, log2fc=log2fc, stability_score=score)

# Add edges with scores
for edge in interactions:
    node_a = edge["preferredName_A"]
    node_b = edge["preferredName_B"]
    score = edge["score"]
    
    # Only add edge if both nodes exist in our query set (redundancy check)
    if G.has_node(node_a) and G.has_node(node_b):
        G.add_edge(node_a, node_b, weight=score)

print(f"Network Statistics:")
print(f" - Total Nodes (Genes) : {G.number_of_nodes()}")
print(f" - Total Edges (Inter) : {G.number_of_edges()}")

# ==========================================================
# CALCULATE HUB GENES CENTRALITY METRICS
# ==========================================================
print("\nCalculating Network Centrality Metrics...")
deg_centrality = nx.degree_centrality(G)
bet_centrality = nx.betweenness_centrality(G)

# Handle eigenvector centrality convergence issues by setting max_iter
try:
    eig_centrality = nx.eigenvector_centrality(G, max_iter=1000)
except nx.PowerIterationFailedConvergence:
    print("[WARNING] Eigenvector centrality failed to converge. Filling with 0.")
    eig_centrality = {node: 0.0 for node in G.nodes()}

# Compile into DataFrame
centrality_data = []
for node in G.nodes():
    centrality_data.append({
        "gene_name": node,
        "gene_id": gene_meta.loc[node, "gene_id"],
        "gene_type": gene_meta.loc[node, "gene_type"],
        "Mean_Log2FC": gene_meta.loc[node, "Mean_Log2FC"],
        "Composite_Stability_Score": gene_meta.loc[node, "Composite_Stability_Score"],
        "Regulation": gene_meta.loc[node, "Regulation"],
        "Degree_Centrality": deg_centrality[node],
        "Betweenness_Centrality": bet_centrality[node],
        "Eigenvector_Centrality": eig_centrality[node],
        "Degree_Count": G.degree[node]
    })

df_centrality = pd.DataFrame(centrality_data)

# Calculate individual ranks for each centrality measure (1 is highest/best)
df_centrality["Degree_Rank"] = df_centrality["Degree_Centrality"].rank(ascending=False, method="min")
df_centrality["Betweenness_Rank"] = df_centrality["Betweenness_Centrality"].rank(ascending=False, method="min")
df_centrality["Eigenvector_Rank"] = df_centrality["Eigenvector_Centrality"].rank(ascending=False, method="min")

# Combine the three rankings by calculating the Average Rank (Borda Count method)
df_centrality["Combined_Rank_Score"] = df_centrality[["Degree_Rank", "Betweenness_Rank", "Eigenvector_Rank"]].mean(axis=1)

# Sort by Combined_Rank_Score (ascending: lower average rank means higher overall centrality)
df_centrality = df_centrality.sort_values(by="Combined_Rank_Score", ascending=True).reset_index(drop=True)

# Save results
df_centrality.to_csv(OUTPUT_CSV, index=False)
print(f"Saved combined centrality results to: {OUTPUT_CSV}")

print("\nTop 15 Identified Hub Genes (Ranked by Combined Centrality):")
print(df_centrality[["gene_name", "Regulation", "Degree_Centrality", "Betweenness_Centrality", "Eigenvector_Centrality", "Combined_Rank_Score"]].head(15))

# ==========================================================
# CREATE INTERACTIVE PYVIS VISUALIZATION
# ==========================================================
print("\nGenerating pyvis network visualization...")
net = Network(height="750px", width="100%", bgcolor="#222222", font_color="white", notebook=False)

# Configure physics layout for nice spacing
net.barnes_hut(gravity=-8000, central_gravity=0.3, spring_length=150, spring_strength=0.04, damping=0.9)

for node, attrs in G.nodes(data=True):
    reg = attrs["regulation"]
    log2fc = attrs["log2fc"]
    stab = attrs["stability_score"]
    deg = G.degree[node]
    
    # Node Styling based on Regulation Status
    if reg == 1:
        color = "#FF4D4D"  # Sleek red
        reg_str = "Upregulated (+1)"
    elif reg == -1:
        color = "#4D94FF"  # Sleek blue
        reg_str = "Downregulated (-1)"
    else:
        color = "#A0A0A0"  # Neutral grey
        reg_str = "Neutral (0)"
        
    # Scale node size based on degree centrality
    size = 15 + (deg_centrality[node] * 60)
    
    hover_text = (
        f"<b>Gene:</b> {node}<br>"
        f"Regulation: {reg_str}<br>"
        f"Mean Log2FC: {log2fc:.4f}<br>"
        f"Stability Score: {stab:.4f}<br>"
        f"Degree (Interactions): {deg}"
    )
    
    net.add_node(node, label=node, size=size, color=color, title=hover_text)

# Add edges with thickness based on STRING score
for node_a, node_b, data in G.edges(data=True):
    weight = data["weight"]
    thickness = weight * 4
    net.add_edge(node_a, node_b, value=weight, width=thickness, title=f"STRING Score: {weight:.3f}", color="#555555")

net.save_graph(OUTPUT_HTML)
print(f"Saved interactive HTML network to: {OUTPUT_HTML}")
print("PHASE IV PPI & HUB GENE ANALYSIS COMPLETE!\n")

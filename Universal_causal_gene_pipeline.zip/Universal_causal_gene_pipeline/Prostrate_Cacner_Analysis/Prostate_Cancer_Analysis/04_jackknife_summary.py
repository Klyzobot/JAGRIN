import os
import glob
import time
import pandas as pd
import numpy as np
import warnings

print("=" * 90)
print("TCGA PRAD JACKKNIFE SUMMARY ANALYSIS (MEMORY OPTIMIZED)")
print("=" * 90)

# ==========================================================
# CONFIGURATION
# ==========================================================

JACKKNIFE_FOLDER = r"C:\Prostate_Cancer_Analysis\Output\Jackknife_Parallel"
MATRIX_FILE = r"C:\Prostate_Cancer_Analysis\Output\expression_matrix.parquet"

OUTPUT_FOLDER = os.path.join(
    JACKKNIFE_FOLDER,
    "Summary"
)

os.makedirs(
    OUTPUT_FOLDER,
    exist_ok=True
)

# ==========================================================
# FIND ALL ITERATION FILES
# ==========================================================

print("\nSearching iteration files...\n")
iteration_files = sorted(glob.glob(os.path.join(JACKKNIFE_FOLDER, "Iteration_*.csv.gz")))
print(f"Iterations Found : {len(iteration_files)}")

if len(iteration_files) == 0:
    print("\nNo iteration files found.")
    exit()

print(f"\nFirst File : {os.path.basename(iteration_files[0])}")
print(f"Last File  : {os.path.basename(iteration_files[-1])}\n")

# ==========================================================
# LOAD ALL ITERATIONS (MEMORY OPTIMIZED APPROACH)
# ==========================================================
print("Extracting universal gene mapping from Parquet matrix...")
# This guarantees we have a complete list of genes even if some were dropped in iterations
unique_genes_df = pd.read_parquet(MATRIX_FILE, columns=['gene_name', 'gene_id', 'gene_type']).drop_duplicates().reset_index(drop=True)
N_GENES = len(unique_genes_df)
M_ITERATIONS = len(iteration_files)

gene_to_idx = {name: i for i, name in enumerate(unique_genes_df['gene_name'])}

print(f"\nAllocating NumPy matrices for {N_GENES} genes across {M_ITERATIONS} iterations (Requires ~1.2 GB RAM)...")
# Pre-allocate using np.nan so missing genes don't skew the statistics
Ranks = np.full((N_GENES, M_ITERATIONS), np.nan, dtype=np.float32)
Scores = np.full((N_GENES, M_ITERATIONS), np.nan, dtype=np.float32)
Log2FC = np.full((N_GENES, M_ITERATIONS), np.nan, dtype=np.float32)
Fold_Change = np.full((N_GENES, M_ITERATIONS), np.nan, dtype=np.float32)
P_Value = np.full((N_GENES, M_ITERATIONS), np.nan, dtype=np.float32)
Passed_Filter = np.zeros((N_GENES, M_ITERATIONS), dtype=np.bool_)

print("\nLoading iteration files...")
start = time.time()

# Only read the columns we actually need to save massive amounts of RAM
cols_to_use = ["gene_name", "Rank", "Score", "Log2FC", "Fold_Change", "P_Value", "Passed_Filter"]

for i, file in enumerate(iteration_files):
    # Pandas is incredibly fast when reading a subset of columns
    df = pd.read_csv(file, usecols=cols_to_use)
    
    # Map to our universal array indices
    row_indices = df['gene_name'].map(gene_to_idx).values
    
    # Filter out any unmapped genes just in case
    valid_mask = ~pd.isna(row_indices)
    valid_row_indices = row_indices[valid_mask].astype(np.int32)
    
    # Safely inject the data into our massive 2D matrices
    Ranks[valid_row_indices, i] = df.loc[valid_mask, 'Rank'].values
    Scores[valid_row_indices, i] = df.loc[valid_mask, 'Score'].values
    Log2FC[valid_row_indices, i] = df.loc[valid_mask, 'Log2FC'].values
    Fold_Change[valid_row_indices, i] = df.loc[valid_mask, 'Fold_Change'].values
    P_Value[valid_row_indices, i] = df.loc[valid_mask, 'P_Value'].values
    Passed_Filter[valid_row_indices, i] = df.loc[valid_mask, 'Passed_Filter'].values

    if (i + 1) % 100 == 0 or (i + 1) == M_ITERATIONS:
        print(f"Loaded {i + 1}/{M_ITERATIONS}")

end = time.time()
print(f"\nLoading Time : {end-start:.2f} sec")

# ==========================================================
# SUMMARY STATISTICS
# ==========================================================

print("\n" + "="*90)
print("CALCULATING GENE STABILITY (VECTORIZED)")
print("="*90)

summary_start = time.time()

print("\nPerforming NumPy Vectorized Math (This takes seconds instead of hours)...")

with warnings.catch_warnings():
    warnings.simplefilter("ignore", category=RuntimeWarning)
    
    # Rank Statistics
    Mean_Rank = np.nanmean(Ranks, axis=1)
    Median_Rank = np.nanmedian(Ranks, axis=1)
    Rank_SD = np.nanstd(Ranks, axis=1, ddof=1)
    Best_Rank = np.nanmin(Ranks, axis=1)
    Worst_Rank = np.nanmax(Ranks, axis=1)
    
    # Score Statistics
    Mean_Score = np.nanmean(Scores, axis=1)
    Score_SD = np.nanstd(Scores, axis=1, ddof=1)
    
    # Expression Statistics
    Mean_Log2FC = np.nanmean(Log2FC, axis=1)
    Mean_FoldChange = np.nanmean(Fold_Change, axis=1)
    Mean_PValue = np.nanmean(P_Value, axis=1)
    
    # Frequency Statistics
    # Since NaNs will be false for <=, we don't need to handle them specially
    Top5_Frequency = np.sum(Ranks <= 5, axis=1)
    Top10_Frequency = np.sum(Ranks <= 10, axis=1)
    Top20_Frequency = np.sum(Ranks <= 20, axis=1)
    Top50_Frequency = np.sum(Ranks <= 50, axis=1)
    Passed_Filter_Frequency = np.sum(Passed_Filter, axis=1)

print("Constructing Summary DataFrame...")

summary_df = unique_genes_df.copy()

summary_df["Mean_Rank"] = Mean_Rank
summary_df["Median_Rank"] = Median_Rank
summary_df["Rank_SD"] = Rank_SD
summary_df["Best_Rank"] = Best_Rank
summary_df["Worst_Rank"] = Worst_Rank

summary_df["Mean_Score"] = Mean_Score
summary_df["Score_SD"] = Score_SD

summary_df["Mean_Log2FC"] = Mean_Log2FC
summary_df["Mean_FoldChange"] = Mean_FoldChange
summary_df["Mean_PValue"] = Mean_PValue

summary_df["Top5_Frequency"] = Top5_Frequency
summary_df["Top10_Frequency"] = Top10_Frequency
summary_df["Top20_Frequency"] = Top20_Frequency
summary_df["Top50_Frequency"] = Top50_Frequency
summary_df["Passed_Filter_Frequency"] = Passed_Filter_Frequency

# Drop genes that were completely filtered out in all iterations (NaN Mean Rank)
summary_df = summary_df.dropna(subset=["Mean_Rank"]).reset_index(drop=True)

summary_end = time.time()
print(f"Summary Created! Time : {summary_end-summary_start:.2f} sec")


# ==========================================================
# COMPOSITE STABILITY SCORE
# ==========================================================

print("\n" + "=" * 90)
print("CALCULATING COMPOSITE STABILITY SCORE")
print("=" * 90)

# Normalize metrics
summary_df["Norm_MeanRank"] = (summary_df["Mean_Rank"] - summary_df["Mean_Rank"].min()) / (summary_df["Mean_Rank"].max() - summary_df["Mean_Rank"].min() + 1e-9)
summary_df["Norm_RankSD"] = (summary_df["Rank_SD"] - summary_df["Rank_SD"].min()) / (summary_df["Rank_SD"].max() - summary_df["Rank_SD"].min() + 1e-9)
summary_df["Norm_Top10"] = (summary_df["Top10_Frequency"] / len(iteration_files))
summary_df["Norm_Filter"] = (summary_df["Passed_Filter_Frequency"] / len(iteration_files))
summary_df["Norm_Score"] = (summary_df["Mean_Score"] - summary_df["Mean_Score"].min()) / (summary_df["Mean_Score"].max() - summary_df["Mean_Score"].min() + 1e-9)

# Composite Stability Score
summary_df["Composite_Stability_Score"] = (
    0.30 * (1 - summary_df["Norm_MeanRank"]) +
    0.20 * (1 - summary_df["Norm_RankSD"]) +
    0.20 * summary_df["Norm_Top10"] +
    0.20 * summary_df["Norm_Filter"] +
    0.10 * summary_df["Norm_Score"]
)

summary_df = summary_df.sort_values(by="Composite_Stability_Score", ascending=False).reset_index(drop=True)
summary_df["Final_Rank"] = summary_df.index + 1

print("\nTop 20 Overall Biomarkers\n")
print(summary_df[["Final_Rank", "gene_name", "gene_type", "Composite_Stability_Score", "Mean_Rank", "Top10_Frequency"]].head(20))


# ==========================================================
# PROTEIN CODING ONLY
# ==========================================================

protein_df = summary_df[summary_df["gene_type"] == "protein_coding"].copy()
protein_df = protein_df.reset_index(drop=True)
protein_df["Protein_Rank"] = protein_df.index + 1

print("\nTop 20 Protein Coding Genes\n")
print(protein_df[["Protein_Rank", "gene_name", "Composite_Stability_Score", "Mean_Rank", "Top10_Frequency"]].head(20))


# ==========================================================
# AMACR REPORT
# ==========================================================

amacr = protein_df[protein_df["gene_name"] == "AMACR"]

if not amacr.empty:
    amacr = amacr.iloc[0]
    report = f"""
====================================================
AMACR STABILITY REPORT
====================================================

Protein Rank : {amacr['Protein_Rank']}
Composite Stability Score : {amacr['Composite_Stability_Score']:.4f}
Mean Rank : {amacr['Mean_Rank']:.2f}
Median Rank : {amacr['Median_Rank']:.2f}
Rank SD : {amacr['Rank_SD']:.2f}
Best Rank : {amacr['Best_Rank']}
Worst Rank : {amacr['Worst_Rank']}

Top 5 Frequency : {amacr['Top5_Frequency']} / {len(iteration_files)}
Top 10 Frequency : {amacr['Top10_Frequency']} / {len(iteration_files)}
Passed Filter : {amacr['Passed_Filter_Frequency']} / {len(iteration_files)}

Mean Log2FC : {amacr['Mean_Log2FC']:.4f}
Mean Fold Change : {amacr['Mean_FoldChange']:.4f}
Mean P Value : {amacr['Mean_PValue']:.3e}

====================================================
"""
    print(report)
    with open(os.path.join(OUTPUT_FOLDER, "AMACR_stability_report.txt"), "w") as f:
        f.write(report)


# ==========================================================
# SAVE FILES
# ==========================================================

summary_df.to_csv(os.path.join(OUTPUT_FOLDER, "jackknife_summary_all_genes.csv"), index=False)
protein_df.to_csv(os.path.join(OUTPUT_FOLDER, "stable_protein_coding_genes.csv"), index=False)

print("\nFiles Generated\n")
print("jackknife_summary_all_genes.csv")
print("stable_protein_coding_genes.csv")
print("AMACR_stability_report.txt")
print("\nAnalysis Completed Successfully!")
# Universal Causal Gene Discovery Pipeline (Version 2.0)

A highly robust, disease-agnostic bioinformatics pipeline for discovering causal master regulator transcription factors directly from bulk RNA-seq data without prior biological bias.

## Features
* **Automated Expression Mapping:** Translates Ensembl IDs to HGNC symbols (MyGene API).
* **Rigorous Statistics:** Uses Mann-Whitney U test with Benjamini-Hochberg FDR correction.
* **Jackknife Validation:** Dynamically triggers Leave-One-Out (N < 150) or 10% Delete-d (N >= 150) stability validation.
* **Borda Count Ranking:** Aggregates PPI Hub metrics formally via Borda Count (Degree, Betweenness, Eigenvector).
* **Pathway Enrichment:** Native integration with GO, KEGG, and Reactome via Enrichr API.
* **Gene Regulatory Network (GRN):** ML-driven reverse-engineering of causal networks via GENIE3 (`ExtraTreesRegressor`).
* **TF Activity Inference:** Predicts Master Regulators using CollecTRI and DecoupleR ULM.
* **Cell Type Deconvolution:** Identifies involved cell lineages automatically.
* **HTML & JSON Reports:** Generates machine-readable and human-readable metadata logs.

## Installation

```bash
pip install -r requirements.txt
```

## Usage

There are two ways to run the pipeline depending on your preference:

### Method 1: Interactive Mode (Recommended for general users)
Simply double-click the script, or run it directly in your IDE or terminal without any arguments:
```bash
python Universal_Causal_Discovery_Pipeline_v2.py
```
The pipeline will launch a guided interface and ask you for the Disease Name, Disease CSV path, and Healthy CSV path directly in the console.

### Method 2: Command Line Interface (Recommended for automated/cloud environments)
Run the pipeline from the command line using standard arguments:

```bash
python Universal_Causal_Discovery_Pipeline_v2.py \
    --name "NAFLD_Analysis" \
    --disease ./example/disease.csv \
    --healthy ./example/healthy.csv \
    --output ./outputs \
    --threads 8 \
    --verbose
```

### Input Format
The input files must be standard CSV expression matrices with genes as rows and samples as columns. The first column header should be `Gene` (or it will automatically detect and rename it).

## Output Structure
* `01_Expression_Matrix/`
* `02_Differential_Expression/dea_results.csv`
* `03_Jackknife_Stability/stable_genes.csv`
* `04_PPI_Network/ppi_centrality.csv`
* `05b_Pathway_Enrichment/`
* `06_GRN_Inference/regulatory_network.csv`
* `07_TF_Activity/top_master_regulators.csv`
* `08_Cell_Type_Association/`
* `run_metadata.json`
* `pipeline_summary.json`
* `pipeline_report.html`
